
export type TransactionType = 'income' | 'expense';
export type GoalType = 'financial' | 'activity';
export type DriverApp = 'Uber' | '99' | 'InDrive' | 'Particular';

export const TRANSACTION_CATEGORIES = [
  'Moradia', 'Alimentação', 'Transporte', 'Lazer', 'Saúde', 'Educação', 'Combustível', 'Assinaturas', 'Outros'
] as const;

export interface Transaction {
  id: string;
  user_id: string;
  external_id?: string | null; // ID único do banco/extrato (UUID ou Identificador)
  description: string;
  amount: number;
  type: TransactionType;
  category: typeof TRANSACTION_CATEGORIES[number] | string;
  payment_method?: string;
  date?: string;
  is_fixed?: boolean;
  created_at?: string;
}

export interface ShoppingItem {
  id: string;
  user_id: string;
  name: string;
  quantity: number;
  unit: string;
  estimated_price: number;
  completed: boolean;
  created_at?: string;
}

export interface DriverSession {
  id: string;
  user_id: string;
  date: string;
  app: DriverApp;
  amount: number;
  trips: number;
  km_driven: number;
  hours_worked: string; // HH:mm
  fuel_spent?: number;
  food_spent?: number;
  other_spent?: number;
  observation?: string;
  created_at?: string;
}

export interface Goal {
  id: string;
  user_id: string;
  description: string;
  target_amount: number;
  current_amount: number;
  type: GoalType;
  deadline?: string;
  created_at?: string;
}
