
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  LayoutDashboard, Wallet, Repeat, Car, ShoppingCart, Flag, Calculator, TrendingUp, LogOut, Plus, ChevronLeft, ChevronRight, ArrowUpCircle, ArrowDownCircle, Trash2, CheckSquare, Square, User as UserIcon, Coins, Smartphone, Database, Clock, MapPin, Fuel, Utensils, Edit3, Calendar, Target, Trophy, ShoppingBag, ReceiptText, Zap, ShieldCheck, Milestone, Landmark, Check
} from 'lucide-react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { useFinances } from './hooks/useFinances';
import { useDriver } from './hooks/useDriver';
import { useGoals } from './hooks/useGoals';
import { useShopping } from './hooks/useShopping';
import { calculateDashboardStats, calculateDriverPerformance, calculateYearlyHistory } from './utils/calculations';
import { formatCurrency, formatDisplayAmount } from './utils/format';
import { 
  calculateCompoundInterest, 
  calculateEmergencyFund, 
  calculateDriverMetrics, 
  calculateMillionJourney, 
  calculateAmortizationSimulation 
} from './utils/financeCalculators';
import { DonutChart, MonthlyBarChart, CategoryBarChart } from './components/Charts';
import { LoadingSpinner } from './components/LoadingSpinner';
import { TransactionModal, GoalModal, ShoppingModal, DriverModal, AporteModal, UpdatePriceModal, DataCenterModal } from './components/Modals';
import { supabase, api } from './services/supabase';
import { Goal, ShoppingItem, DriverSession } from './types';

const DASHBOARD_COLORS = ['#10b981', '#3b82f6', '#8b5cf6', '#f59e0b', '#ef4444', '#06b6d4', '#ec4899'];

const DecorativeBackground: React.FC<{ type: 'balance' | 'income' | 'expense' }> = ({ type }) => {
  const color = type === 'income' ? '#10b981' : type === 'expense' ? '#f43f5e' : '#ffffff';
  return (
    <div className="absolute inset-0 pointer-events-none opacity-[0.04] overflow-hidden">
      <svg width="100%" height="100%" viewBox="0 0 200 100" preserveAspectRatio="none">
        {type === 'balance' ? (
          <path d="M0,80 Q50,20 100,80 T200,80" fill="none" stroke={color} strokeWidth="12" />
        ) : type === 'income' ? (
          <path d="M0,100 L40,60 L80,80 L120,20 L160,40 L200,10 V100 Z" fill={color} />
        ) : (
          <path d="M0,20 L40,60 L80,40 L120,80 L160,60 L200,90 V100 L0,100 Z" fill={color} />
        )}
      </svg>
    </div>
  );
};

const LoginScreen = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [loading, setLoading] = useState(false);
  const { notify } = useAuth();

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === 'login') {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        notify('Verifique seu e-mail!', 'success');
      }
    } catch (err: any) { notify(err.message, 'error'); } finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-6">
      <div className="w-full max-w-md bg-slate-900 border border-white/5 p-10 rounded-[3rem] shadow-2xl animate-in zoom-in duration-500">
        <div className="flex flex-col items-center mb-10">
          <div className="bg-emerald-500 p-4 rounded-[2rem] shadow-2xl shadow-emerald-500/20 mb-6">
            <TrendingUp size={32} className="text-slate-950" strokeWidth={3} />
          </div>
          <h1 className="text-3xl font-black uppercase tracking-tighter text-white">FIN<span className="text-emerald-500">CONTROL</span></h1>
        </div>
        <form onSubmit={handleAuth} className="space-y-4">
          <input type="email" placeholder="Email" className="w-full bg-slate-800/50 p-4 rounded-2xl text-white outline-none focus:ring-2 ring-emerald-500/20" value={email} onChange={e => setEmail(e.target.value)} required />
          <input type="password" placeholder="Senha" className="w-full bg-slate-800/50 p-4 rounded-2xl text-white outline-none focus:ring-2 ring-emerald-500/20" value={password} onChange={e => setPassword(e.target.value)} required />
          <button disabled={loading} className="w-full bg-emerald-500 text-slate-950 font-black py-5 rounded-2xl uppercase shadow-xl transition-all active:scale-95">{loading ? 'Aguarde...' : mode === 'login' ? 'Acessar' : 'Registrar'}</button>
        </form>
        <p onClick={() => setMode(mode === 'login' ? 'register' : 'login')} className="text-center text-slate-500 mt-6 text-[10px] font-black uppercase cursor-pointer hover:text-emerald-500 transition-colors">{mode === 'login' ? 'Não tem conta? Cadastre-se' : 'Já tem conta? Login'}</p>
      </div>
    </div>
  );
};

const CalculatorContent = () => {
  const [calcTab, setCalcTab] = useState<'juros' | 'milhao' | 'reserva' | 'driver' | 'amortizacao'>('juros');
  
  const [inputs, setInputs] = useState<any>({
    jInitial: '100000', jMonthly: '50000', jRate: '12', jYears: '10',
    mMonthly: '100000', mRate: '12',
    rExpenses: '300000', rJob: 'clt',
    dCar: 'rented', dKm: '4000', dFuelPrice: '5.50', dEfficiency: '10', dRent: '200000', dInstall: '0', dInsur: '25000', dIpva: '120000', dIncome: '400000', dMaintenance: '0.15', dDepreciation: '50000', dInterest: '0',
    aDebt: '5000000', aInstall: '150000', aExtra: '1000000'
  });
  
  const [results, setResults] = useState<any>(null);

  const handleCalc = () => {
    let res = null;
    if (calcTab === 'juros') {
      res = calculateCompoundInterest({
        initialAmount: parseInt(inputs.jInitial) / 100,
        monthlyContribution: parseInt(inputs.jMonthly) / 100,
        annualRate: parseFloat(inputs.jRate),
        years: parseInt(inputs.jYears)
      });
    } else if (calcTab === 'milhao') {
      res = calculateMillionJourney(parseInt(inputs.mMonthly) / 100, parseFloat(inputs.mRate));
    } else if (calcTab === 'reserva') {
      res = calculateEmergencyFund(parseInt(inputs.rExpenses) / 100, inputs.rJob);
    } else if (calcTab === 'driver') {
      res = calculateDriverMetrics({
        carType: inputs.dCar,
        monthlyKm: parseFloat(inputs.dKm),
        fuelPrice: parseFloat(inputs.dFuelPrice),
        fuelEfficiency: parseFloat(inputs.dEfficiency),
        monthlyRent: parseInt(inputs.dRent) / 100,
        carInstallment: parseInt(inputs.dInstall) / 100,
        insurance: parseInt(inputs.dInsur) / 100,
        ipvaAnnual: parseInt(inputs.dIpva) / 100,
        desiredNetIncome: parseInt(inputs.dIncome) / 100,
        maintenancePerKm: parseFloat(inputs.dMaintenance),
        depreciationMonthly: parseInt(inputs.dDepreciation) / 100,
        interestRate: parseFloat(inputs.dInterest)
      });
    } else if (calcTab === 'amortizacao') {
      res = calculateAmortizationSimulation(
        parseInt(inputs.aDebt) / 100,
        parseInt(inputs.aInstall) / 100,
        parseInt(inputs.aExtra) / 100
      );
    }
    setResults(res);
  };

  useEffect(() => { setResults(null); }, [calcTab]);

  const navItems = [
    { id: 'juros', icon: TrendingUp, label: 'Investimento' },
    { id: 'milhao', icon: Milestone, label: '1 Milhão' },
    { id: 'reserva', icon: ShieldCheck, label: 'Reserva' },
    { id: 'driver', icon: Car, label: 'Uber/99' },
    { id: 'amortizacao', icon: Landmark, label: 'Amortização' }
  ];

  return (
    <div className="space-y-8 animate-in slide-in-from-bottom duration-700 pb-20">
      <div className="flex flex-wrap gap-2 justify-center lg:justify-start">
        {navItems.map(item => (
          <button key={item.id} onClick={() => setCalcTab(item.id as any)} className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${calcTab === item.id ? 'bg-emerald-500 text-slate-950 shadow-lg' : 'bg-slate-900/50 text-slate-500 hover:text-white border border-white/5'}`}>
            <item.icon size={14} /> {item.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <div className="lg:col-span-5 bg-slate-900 border border-white/5 p-6 md:p-8 rounded-[2.5rem] shadow-2xl space-y-6">
          <div className="space-y-4">
            {calcTab === 'juros' && (
              <>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-500 uppercase">Patrimônio Inicial</label>
                  <input type="text" value={formatDisplayAmount(inputs.jInitial)} onChange={e => setInputs({...inputs, jInitial: e.target.value.replace(/\D/g, "")})} className="w-full bg-slate-950 p-4 rounded-xl text-white outline-none border border-white/5 font-mono" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-500 uppercase">Aporte Mensal</label>
                  <input type="text" value={formatDisplayAmount(inputs.jMonthly)} onChange={e => setInputs({...inputs, jMonthly: e.target.value.replace(/\D/g, "")})} className="w-full bg-slate-950 p-4 rounded-xl text-white outline-none border border-white/5 font-mono" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-slate-500 uppercase">Taxa Anual (%)</label>
                    <input type="number" value={inputs.jRate} onChange={e => setInputs({...inputs, jRate: e.target.value})} className="w-full bg-slate-950 p-4 rounded-xl text-white outline-none border border-white/5" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-slate-500 uppercase">Anos</label>
                    <input type="number" value={inputs.jYears} onChange={e => setInputs({...inputs, jYears: e.target.value})} className="w-full bg-slate-950 p-4 rounded-xl text-white outline-none border border-white/5" />
                  </div>
                </div>
              </>
            )}

            {calcTab === 'milhao' && (
              <>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-500 uppercase">Aporte Mensal Atual</label>
                  <input type="text" value={formatDisplayAmount(inputs.mMonthly)} onChange={e => setInputs({...inputs, mMonthly: e.target.value.replace(/\D/g, "")})} className="w-full bg-slate-950 p-4 rounded-xl text-white outline-none border border-white/5 font-mono" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-500 uppercase">Rentabilidade Anual (%)</label>
                  <input type="number" value={inputs.mRate} onChange={e => setInputs({...inputs, mRate: e.target.value})} className="w-full bg-slate-950 p-4 rounded-xl text-white outline-none border border-white/5" />
                </div>
              </>
            )}

            {calcTab === 'reserva' && (
              <>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-500 uppercase">Custo de Vida Mensal</label>
                  <input type="text" value={formatDisplayAmount(inputs.rExpenses)} onChange={e => setInputs({...inputs, rExpenses: e.target.value.replace(/\D/g, "")})} className="w-full bg-slate-950 p-4 rounded-xl text-white outline-none border border-white/5 font-mono" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-500 uppercase">Tipo de Ocupação</label>
                  <select value={inputs.rJob} onChange={e => setInputs({...inputs, rJob: e.target.value as any})} className="w-full bg-slate-950 p-4 rounded-xl text-white outline-none border border-white/5 font-black text-[10px] uppercase">
                    <option value="public">Servidor Público</option>
                    <option value="clt">CLT / Privado</option>
                    <option value="autonomous">Autônomo / Empresário</option>
                  </select>
                </div>
              </>
            )}

            {calcTab === 'driver' && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-slate-500 uppercase">Veículo</label>
                    <select value={inputs.dCar} onChange={e => setInputs({...inputs, dCar: e.target.value})} className="w-full bg-slate-950 p-4 rounded-xl text-white border border-white/5 text-[9px] font-black uppercase">
                      <option value="owned">Próprio</option>
                      <option value="rented">Alugado</option>
                      <option value="financed">Financiado</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-slate-500 uppercase">KM Mensal</label>
                    <input type="number" value={inputs.dKm} onChange={e => setInputs({...inputs, dKm: e.target.value})} className="w-full bg-slate-950 p-4 rounded-xl text-white border border-white/5" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-slate-500 uppercase">Preço Litro</label>
                    <input type="number" step="0.01" value={inputs.dFuelPrice} onChange={e => setInputs({...inputs, dFuelPrice: e.target.value})} className="w-full bg-slate-950 p-4 rounded-xl text-white border border-white/5" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-slate-500 uppercase">Consumo (KM/L)</label>
                    <input type="number" step="0.1" value={inputs.dEfficiency} onChange={e => setInputs({...inputs, dEfficiency: e.target.value})} className="w-full bg-slate-950 p-4 rounded-xl text-white border border-white/5" />
                  </div>
                </div>
                
                <div className="p-4 bg-slate-950/50 rounded-2xl border border-white/5 space-y-4">
                   <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest text-center">Custos Fixos Detalhados</p>
                   {inputs.dCar === 'rented' ? (
                     <div className="space-y-1">
                        <label className="text-[8px] font-black text-slate-500 uppercase">Aluguel Mensal</label>
                        <input type="text" value={formatDisplayAmount(inputs.dRent)} onChange={e => setInputs({...inputs, dRent: e.target.value.replace(/\D/g, "")})} className="w-full bg-slate-900 p-3 rounded-xl text-white border border-white/5 text-xs font-mono" />
                     </div>
                   ) : (
                     <>
                        <div className="grid grid-cols-2 gap-4">
                           <div className="space-y-1">
                             <label className="text-[8px] font-black text-slate-500 uppercase">Seguro Anual</label>
                             <input type="text" value={formatDisplayAmount(inputs.dInsur)} onChange={e => setInputs({...inputs, dInsur: e.target.value.replace(/\D/g, "")})} className="w-full bg-slate-900 p-3 rounded-xl text-white border border-white/5 text-xs font-mono" />
                           </div>
                           <div className="space-y-1">
                             <label className="text-[8px] font-black text-slate-500 uppercase">IPVA Anual</label>
                             <input type="text" value={formatDisplayAmount(inputs.dIpva)} onChange={e => setInputs({...inputs, dIpva: e.target.value.replace(/\D/g, "")})} className="w-full bg-slate-900 p-3 rounded-xl text-white border border-white/5 text-xs font-mono" />
                           </div>
                        </div>
                        {inputs.dCar === 'financed' && (
                           <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-1">
                                <label className="text-[8px] font-black text-slate-500 uppercase">Parcela</label>
                                <input type="text" value={formatDisplayAmount(inputs.dInstall)} onChange={e => setInputs({...inputs, dInstall: e.target.value.replace(/\D/g, "")})} className="w-full bg-slate-900 p-3 rounded-xl text-white border border-white/5 text-xs font-mono" />
                              </div>
                              <div className="space-y-1">
                                <label className="text-[8px] font-black text-slate-500 uppercase">Juros Anual (%)</label>
                                <input type="number" step="0.1" value={inputs.dInterest} onChange={e => setInputs({...inputs, dInterest: e.target.value})} className="w-full bg-slate-900 p-3 rounded-xl text-white border border-white/5 text-xs" />
                              </div>
                           </div>
                        )}
                        <div className="grid grid-cols-2 gap-4">
                           <div className="space-y-1">
                             <label className="text-[8px] font-black text-slate-500 uppercase">Manut. por KM</label>
                             <input type="number" step="0.01" value={inputs.dMaintenance} onChange={e => setInputs({...inputs, dMaintenance: e.target.value})} className="w-full bg-slate-900 p-3 rounded-xl text-white border border-white/5 text-xs" />
                           </div>
                           <div className="space-y-1">
                             <label className="text-[8px] font-black text-slate-500 uppercase">Depreciação Mensal</label>
                             <input type="text" value={formatDisplayAmount(inputs.dDepreciation)} onChange={e => setInputs({...inputs, dDepreciation: e.target.value.replace(/\D/g, "")})} className="w-full bg-slate-900 p-3 rounded-xl text-white border border-white/5 text-xs font-mono" />
                           </div>
                        </div>
                     </>
                   )}
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-500 uppercase">Lucro Líquido Desejado</label>
                  <input type="text" value={formatDisplayAmount(inputs.dIncome)} onChange={e => setInputs({...inputs, dIncome: e.target.value.replace(/\D/g, "")})} className="w-full bg-slate-900 border border-white/5 p-4 rounded-xl text-white border border-white/5 font-mono" />
                </div>
              </div>
            )}

            {calcTab === 'amortizacao' && (
              <>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-500 uppercase">Saldo Devedor Atual</label>
                  <input type="text" value={formatDisplayAmount(inputs.aDebt)} onChange={e => setInputs({...inputs, aDebt: e.target.value.replace(/\D/g, "")})} className="w-full bg-slate-950 p-4 rounded-xl text-white outline-none border border-white/5 font-mono" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-500 uppercase">Valor da Parcela</label>
                  <input type="text" value={formatDisplayAmount(inputs.aInstall)} onChange={e => setInputs({...inputs, aInstall: e.target.value.replace(/\D/g, "")})} className="w-full bg-slate-950 p-4 rounded-xl text-white outline-none border border-white/5 font-mono" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-500 uppercase">Valor Extra para Amortizar</label>
                  <input type="text" value={formatDisplayAmount(inputs.aExtra)} onChange={e => setInputs({...inputs, aExtra: e.target.value.replace(/\D/g, "")})} className="w-full bg-slate-950 p-4 rounded-xl text-white outline-none border border-white/5 font-mono" />
                </div>
              </>
            )}
          </div>
          <button onClick={handleCalc} className="w-full bg-emerald-500 text-slate-950 font-black py-5 rounded-2xl uppercase tracking-widest shadow-xl active:scale-95 transition-all flex items-center justify-center gap-3">
            <Zap size={18} fill="currentColor" /> Simular Agora
          </button>
        </div>

        <div className="lg:col-span-7 h-full">
          {!results ? (
            <div className="h-full min-h-[400px] bg-slate-900/20 border-2 border-dashed border-white/5 rounded-[2.5rem] flex flex-col items-center justify-center text-center p-10">
               <div className="bg-slate-900 p-6 rounded-full mb-6 border border-white/5"><Calculator size={48} className="text-slate-700" /></div>
               <p className="text-[10px] font-black uppercase text-slate-600 tracking-widest max-w-[200px]">Ajuste os parâmetros e clique em simular para ver a mágica da matemática financeira.</p>
            </div>
          ) : (
            <div className="space-y-6 animate-in fade-in duration-700 h-full">
              {calcTab === 'juros' && results && (
                <div className="h-full flex flex-col gap-6">
                  <div className="bg-emerald-500 p-8 md:p-10 rounded-[2.5rem] text-slate-950 shadow-2xl relative overflow-hidden">
                    <TrendingUp size={120} className="absolute -top-6 -right-6 opacity-10" />
                    <span className="text-[10px] font-black uppercase tracking-widest opacity-60 block mb-2">Montante Final Estimado</span>
                    <h3 className="text-4xl md:text-5xl font-black tracking-tighter">{formatCurrency(results.finalAmount)}</h3>
                    <div className="grid grid-cols-2 gap-6 mt-10 pt-8 border-t border-slate-950/10">
                       <div>
                          <p className="text-[9px] font-black uppercase opacity-60">Seu Bolso</p>
                          <p className="text-xl font-black">{formatCurrency(results.totalInvested)}</p>
                       </div>
                       <div>
                          <p className="text-[9px] font-black uppercase opacity-60">Lucro de Juros</p>
                          <p className="text-xl font-black">{formatCurrency(results.totalInterest)}</p>
                       </div>
                    </div>
                  </div>
                  <div className="bg-slate-900/40 border border-white/5 p-8 rounded-[2rem] flex-1">
                    <h4 className="text-[10px] font-black uppercase text-slate-500 mb-8 tracking-widest">Evolução do Patrimônio</h4>
                    <div className="flex items-end gap-1.5 md:gap-3 h-32 md:h-40">
                       {(results.monthlyBreakdown || []).map((b: any, i: number) => (
                         <div key={i} className="flex-1 bg-emerald-500/10 rounded-t-lg group relative transition-all hover:bg-emerald-500" style={{ height: `${(b.balance / results.finalAmount) * 100}%` }}>
                            <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-[9px] p-2 rounded-lg opacity-0 group-hover:opacity-100 transition-all pointer-events-none whitespace-nowrap shadow-2xl z-50">
                               Ano {b.year}: {formatCurrency(b.balance)}
                            </div>
                         </div>
                       ))}
                    </div>
                  </div>
                </div>
              )}

              {calcTab === 'milhao' && results && (
                <div className="space-y-6">
                  <div className="bg-amber-400 p-10 rounded-[2.5rem] text-slate-950 shadow-2xl">
                    <Milestone className="mb-4" size={32} />
                    <span className="text-[10px] font-black uppercase tracking-widest opacity-60 block mb-2">Tempo até o primeiro Milhão</span>
                    <h3 className="text-5xl font-black tracking-tighter">{results.yearsToMillion} <span className="text-2xl opacity-60">Anos</span></h3>
                    <p className="mt-4 text-[11px] font-bold uppercase tracking-wide opacity-80">Ou aproximadamente {results.monthsToMillion} meses de disciplina financeira.</p>
                  </div>
                  <div className="bg-slate-900 p-8 rounded-[2.5rem] border border-white/5">
                    <span className="text-[10px] font-black uppercase text-slate-500 tracking-widest block mb-2">Aceleração de Resultados</span>
                    <p className="text-[11px] font-bold text-slate-300 leading-relaxed mb-6">Para encurtar sua jornada e chegar no milhão em apenas <span className="text-amber-400">10 anos</span>, seu aporte mensal deveria ser de:</p>
                    <div className="bg-white/5 p-6 rounded-2xl border border-white/5">
                       <h4 className="text-3xl font-black text-white">{formatCurrency(results.requiredContributionForTargetYears)}</h4>
                       <span className="text-[9px] font-black uppercase text-slate-500">Aporte mensal sugerido</span>
                    </div>
                  </div>
                </div>
              )}

              {calcTab === 'reserva' && results && (
                <div className="h-full flex flex-col">
                  <div className="bg-indigo-600 p-10 rounded-[2.5rem] text-white shadow-2xl flex-1 flex flex-col justify-center">
                    <ShieldCheck className="mb-6 opacity-40" size={48} />
                    <span className="text-[10px] font-black uppercase tracking-widest opacity-70 mb-2 block">Seu Porto Seguro Financeiro</span>
                    <h3 className="text-5xl font-black tracking-tighter">{formatCurrency(results.targetAmount)}</h3>
                    <div className="mt-10 grid grid-cols-2 gap-4">
                       <div className="bg-black/20 p-4 rounded-2xl">
                          <p className="text-[9px] font-black uppercase opacity-60">Cobertura</p>
                          <p className="text-lg font-black">{results.monthsRequired} Meses</p>
                       </div>
                       <div className="bg-black/20 p-4 rounded-2xl">
                          <p className="text-[9px] font-black uppercase opacity-60">Proteção</p>
                          <p className="text-lg font-black">Nível {results.monthsRequired >= 12 ? 'Máximo' : 'Ideal'}</p>
                       </div>
                    </div>
                  </div>
                </div>
              )}

              {calcTab === 'driver' && results && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-slate-900 p-8 rounded-[2.5rem] border border-white/5 shadow-xl">
                    <span className="text-[10px] font-black uppercase text-slate-500 tracking-widest block mb-4">Métrica por KM</span>
                    <h3 className="text-4xl font-black text-emerald-400">{formatCurrency(results.minPricePerKm)}</h3>
                    <p className="text-[10px] font-bold text-slate-500 uppercase mt-2">Valor mínimo de custo/lucro por KM rodado.</p>
                  </div>
                  <div className="bg-slate-900 p-8 rounded-[2.5rem] border border-white/5 shadow-xl">
                    <span className="text-[10px] font-black uppercase text-slate-500 tracking-widest block mb-4">Métrica por Hora</span>
                    <h3 className="text-4xl font-black text-amber-400">{formatCurrency(results.minPricePerHour)}</h3>
                    <p className="text-[10px] font-bold text-slate-500 uppercase mt-2">Ganhos necessários por hora logada.</p>
                  </div>
                  <div className="md:col-span-2 bg-slate-900/60 p-8 rounded-[2.5rem] border border-white/5">
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                       <div>
                          <p className="text-[9px] font-black text-slate-500 uppercase">Custos Fixos</p>
                          <p className="text-lg font-black">{formatCurrency(results.fixedCosts)}</p>
                       </div>
                       <div>
                          <p className="text-[9px] font-black text-slate-500 uppercase">Combustível + Manut</p>
                          <p className="text-lg font-black">{formatCurrency(results.variableCosts)}</p>
                       </div>
                       <div className="col-span-2 md:col-span-1 border-t md:border-t-0 md:border-l border-white/10 pt-4 md:pt-0 md:pl-6">
                          <p className="text-[9px] font-black text-emerald-400 uppercase">Meta Bruta Mensal</p>
                          <p className="text-2xl font-black text-white">{formatCurrency(results.requiredGrossRevenue)}</p>
                       </div>
                    </div>
                  </div>
                </div>
              )}

              {calcTab === 'amortizacao' && results && (
                <div className="space-y-6">
                  <div className="bg-white p-10 rounded-[2.5rem] text-slate-950 shadow-2xl">
                    <Milestone className="mb-4 text-emerald-600" size={32} />
                    <span className="text-[10px] font-black uppercase tracking-widest opacity-60 block mb-2">Tempo de Vida Economizado</span>
                    <h3 className="text-5xl font-black tracking-tighter">{results.monthsSaved} <span className="text-2xl opacity-60">Meses</span></h3>
                    <p className="mt-4 text-[11px] font-bold uppercase tracking-wide opacity-80">Você reduziu sua dívida em {results.debtReducedPercent}% com este aporte.</p>
                  </div>
                  <div className="bg-slate-900 p-8 rounded-[2.5rem] border border-white/5">
                    <span className="text-[10px] font-black uppercase text-slate-500 tracking-widest block mb-4">Novo Cenário</span>
                    <div className="flex items-center gap-6">
                       <div className="bg-white/5 p-6 rounded-2xl flex-1 text-center">
                          <span className="text-[8px] font-black uppercase text-slate-500 block">Restam</span>
                          <span className="text-3xl font-black text-white">{results.remainingMonths}</span>
                          <span className="text-[8px] font-black uppercase text-slate-500 block">Parcelas</span>
                       </div>
                       <div className="w-12 h-12 flex items-center justify-center bg-emerald-500 rounded-full shadow-lg shadow-emerald-500/20"><Check size={24} className="text-slate-950" strokeWidth={3} /></div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const AppContent = () => {
  const { user, signOut, loading: authLoading, toast, notify } = useAuth();
  const { transactions = [], fixedTransactions = [], fetchTransactions, fetchFixed, deleteTransaction, loading: dataLoading } = useFinances();
  const { sessions: driverSessions = [], fetchSessions: fetchDriver, addSession: addDriver, deleteSession: deleteDriver } = useDriver();
  const { goals = [], fetchGoals, deleteGoal } = useGoals();
  const { items: shoppingList = [], fetchItems: fetchShopping, toggleComplete: toggleShop, addItem: addShop, deleteItem: deleteShop } = useShopping();
  
  const [activeTab, setActiveTab] = useState<'inicio' | 'transactions' | 'fixed' | 'driver-panel' | 'shopping' | 'goals' | 'calculator'>('inicio');
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7));
  const [selectedDay, setSelectedDay] = useState(new Date().toISOString().split('T')[0]);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [driverMode, setDriverMode] = useState<'DIARIO' | 'MENSAL'>('MENSAL');
  
  const [modals, setModals] = useState({ transaction: false, goal: false, shop: false, driver: false, aporte: false, price: false, dataCenter: false });
  const [selectedGoal, setSelectedGoal] = useState<Goal | null>(null);
  const [selectedItem, setSelectedItem] = useState<ShoppingItem | null>(null);
  const [selectedDriverSession, setSelectedDriverSession] = useState<DriverSession | null>(null);

  const openNewModal = useCallback(() => {
    if (activeTab === 'goals') setModals(m => ({ ...m, goal: true }));
    else if (activeTab === 'shopping') setModals(m => ({ ...m, shop: true }));
    else if (activeTab === 'driver-panel') setModals(m => ({ ...m, driver: true }));
    else setModals(m => ({ ...m, transaction: true }));
  }, [activeTab]);

  useEffect(() => {
    if (!user) return;
    const load = async () => {
      if (activeTab === 'inicio') { fetchTransactions(); fetchFixed(); fetchGoals(); fetchShopping(); }
      if (activeTab === 'transactions') fetchTransactions();
      if (activeTab === 'fixed') fetchFixed();
      if (activeTab === 'driver-panel') fetchDriver();
      if (activeTab === 'goals') fetchGoals();
      if (activeTab === 'shopping') fetchShopping();
    };
    load();
  }, [activeTab, user, fetchTransactions, fetchFixed, fetchDriver, fetchGoals, fetchShopping]);

  const dashboardStats = useMemo(() => calculateDashboardStats(transactions || [], fixedTransactions || [], selectedMonth), [transactions, fixedTransactions, selectedMonth]);
  const yearlyHistory = useMemo(() => calculateYearlyHistory(transactions || [], fixedTransactions || [], selectedYear), [transactions, fixedTransactions, selectedYear]);
  const driverStats = useMemo(() => calculateDriverPerformance(driverSessions || [], transactions || [], fixedTransactions || [], selectedMonth, selectedDay, driverMode === 'DIARIO' ? 'diario' : 'mensal'), [driverSessions, transactions, fixedTransactions, selectedMonth, selectedDay, driverMode]);
  
  const navItems = [
    { id: 'inicio', icon: LayoutDashboard, label: 'Início' },
    { id: 'transactions', icon: Wallet, label: 'Lançamentos' },
    { id: 'fixed', icon: Repeat, label: 'Contas Fixas' },
    { id: 'driver-panel', icon: Car, label: 'Painel Motorista' },
    { id: 'shopping', icon: ShoppingCart, label: 'Lista Compras' },
    { id: 'goals', icon: Flag, label: 'Metas' },
    { id: 'calculator', icon: Calculator, label: 'Calculadora' }
  ];

  const handleImportData = async (data: any[]) => {
    try {
      if (!Array.isArray(data)) return;
      const { error } = await api.transactions.upsert('transactions', data.map(item => ({ ...item, user_id: user?.id })));
      if (error) throw error;
      notify(`${data.length} lançamentos processados!`);
      await fetchTransactions();
      await fetchFixed();
    } catch (err: any) { notify("Erro: " + err.message, "error"); }
  };

  const changeMonth = (direction: number) => {
    const [year, month] = selectedMonth.split('-').map(Number);
    const date = new Date(year, month - 1 + direction, 15);
    setSelectedMonth(date.toISOString().slice(0, 7));
  };

  const changeDay = (direction: number) => {
    const date = new Date(selectedDay + 'T12:00:00');
    date.setDate(date.getDate() + direction);
    const newDay = date.toISOString().split('T')[0];
    setSelectedDay(newDay);
    setSelectedMonth(newDay.slice(0, 7));
  };

  if (authLoading) return <LoadingSpinner />;
  if (!user) return <LoginScreen />;

  const currentTabTrans = activeTab === 'fixed' 
    ? (fixedTransactions || []) 
    : (transactions || []).filter(t => String(t.date || "").includes(selectedMonth));

  const currentMonthSessions = (driverSessions || []).filter(s => String(s.date || "").includes(selectedMonth));

  return (
    <div className="flex flex-col lg:flex-row h-screen bg-slate-950 text-slate-100 overflow-hidden font-sans">
      {toast && (
        <div className={`fixed top-6 right-6 z-[100] p-4 rounded-2xl shadow-2xl border flex items-center gap-3 animate-in slide-in-from-right duration-300 ${toast.type === 'error' ? 'bg-rose-500/10 border-rose-500/20 text-rose-500' : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-500'}`}>
          <span className="text-[10px] font-black uppercase tracking-widest">{toast.msg}</span>
        </div>
      )}

      <aside className="hidden lg:flex flex-col w-64 border-r border-white/5 bg-[#020617] shrink-0">
        <div className="p-8 flex items-center gap-3">
          <div className="bg-emerald-500 p-2 rounded-xl shadow-lg transition-transform hover:scale-110 cursor-pointer"><TrendingUp size={20} className="text-slate-950" strokeWidth={3} /></div>
          <h1 className="text-lg font-black uppercase text-white tracking-tighter">FIN<span className="text-emerald-500">CONTROL</span></h1>
        </div>
        <nav className="flex-1 px-4 space-y-1 overflow-y-auto no-scrollbar">
          {navItems.map(item => (
            <button key={item.id} onClick={() => setActiveTab(item.id as any)} className={`flex items-center gap-4 w-full px-5 py-3 rounded-2xl transition-all ${activeTab === item.id ? 'bg-emerald-500 text-slate-950 font-black shadow-lg shadow-emerald-500/10' : 'text-slate-400 hover:bg-white/5'}`}>
              <item.icon size={18} />
              <span className="text-[10px] font-black uppercase tracking-widest">{item.label}</span>
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-white/5">
          <button onClick={() => setModals(m => ({ ...m, dataCenter: true }))} className="flex items-center gap-4 w-full px-5 py-4 rounded-2xl text-indigo-400 hover:bg-indigo-500/10 transition-all mb-2">
             <Database size={18} /><span className="text-[10px] font-black uppercase">Gestão de Dados</span>
          </button>
          <button onClick={signOut} className="w-full flex items-center gap-3 p-4 rounded-2xl text-rose-500 font-black text-[9px] uppercase tracking-widest hover:bg-rose-500/5 transition-all"><LogOut size={16} /> Sair</button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col h-screen relative overflow-hidden">
        <header className="flex items-center justify-between p-3 md:p-6 bg-slate-950/80 backdrop-blur-xl border-b border-white/5 z-30 min-h-[72px]">
          {activeTab !== 'calculator' ? (
            <>
              <div className="flex items-center gap-2 bg-slate-900/40 p-1.5 rounded-xl border border-white/5 shadow-inner animate-in fade-in zoom-in duration-300">
                 <button onClick={() => (activeTab === 'driver-panel' && driverMode === 'DIARIO') ? changeDay(-1) : changeMonth(-1)} className="p-2 hover:bg-white/5 rounded-lg text-slate-400"><ChevronLeft size={18} /></button>
                 <div className="relative flex items-center justify-center min-w-[120px]">
                   <span className="text-[10px] font-black uppercase tracking-widest px-3 text-center pointer-events-none">
                     {activeTab === 'driver-panel' && driverMode === 'DIARIO' 
                       ? new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' }).format(new Date(selectedDay + 'T12:00:00'))
                       : new Intl.DateTimeFormat('pt-BR', { month: 'short', year: 'numeric' }).format(new Date(selectedMonth + '-15'))}
                   </span>
                   <input 
                     type={activeTab === 'driver-panel' && driverMode === 'DIARIO' ? "date" : "month"} 
                     value={activeTab === 'driver-panel' && driverMode === 'DIARIO' ? selectedDay : selectedMonth}
                     onChange={(e) => {
                       const val = e.target.value;
                       if (!val) return;
                       if (activeTab === 'driver-panel' && driverMode === 'DIARIO') {
                         setSelectedDay(val);
                         setSelectedMonth(val.slice(0, 7));
                       } else {
                         setSelectedMonth(val);
                       }
                     }}
                     className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                     title="Escolher data"
                   />
                 </div>
                 <button onClick={() => (activeTab === 'driver-panel' && driverMode === 'DIARIO') ? changeDay(1) : changeMonth(1)} className="p-2 hover:bg-white/5 rounded-lg text-slate-400"><ChevronRight size={18} /></button>
              </div>
              <div className="flex gap-2">
                <button onClick={() => setModals(m => ({ ...m, dataCenter: true }))} className="lg:hidden p-3 bg-slate-900 rounded-xl text-indigo-400 border border-white/5"><Database size={18} /></button>
                <button onClick={openNewModal} className="bg-emerald-500 text-slate-950 px-4 md:px-6 py-2.5 rounded-xl font-black text-[10px] uppercase shadow-xl hover:scale-105 transition-all flex items-center gap-2">
                  <Plus size={16} strokeWidth={4} /> <span className="hidden md:inline">Novo</span>
                </button>
              </div>
            </>
          ) : (
            <div className="flex items-center gap-3 animate-in slide-in-from-left duration-300">
               <div className="bg-slate-900 p-2.5 rounded-xl border border-white/5 shadow-xl"><Calculator className="text-emerald-500" size={24} strokeWidth={2.5}/></div>
               <div>
                 <h2 className="text-lg font-black uppercase tracking-tighter leading-none">Matemática <span className="text-emerald-500">Financeira</span></h2>
                 <p className="text-[8px] font-bold text-slate-500 uppercase tracking-widest mt-1">Simuladores de precisão</p>
               </div>
            </div>
          )}
        </header>

        <div className="flex-1 overflow-y-auto p-4 md:p-10 no-scrollbar pb-32">
          <div className="max-w-7xl mx-auto">
            {dataLoading ? <LoadingSpinner /> : (
              <div className="animate-in fade-in duration-700">
                {activeTab === 'inicio' && (
                  <div className="space-y-12">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                      <div className="bg-slate-900/40 p-10 rounded-[2.5rem] border border-white/5 shadow-2xl relative overflow-hidden group">
                        <DecorativeBackground type="balance" />
                        <span className="relative z-10 text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] block mb-2 flex items-center gap-2">
                          <Check size={14} className="text-emerald-500" /> Saldo Líquido
                        </span>
                        <h3 className={`relative z-10 text-4xl font-black tracking-tighter ${dashboardStats.balance >= 0 ? 'text-white' : 'text-rose-500'}`}>{formatCurrency(dashboardStats.balance)}</h3>
                      </div>
                      <div className="bg-slate-900/40 p-10 rounded-[2.5rem] border border-white/5 shadow-2xl relative overflow-hidden group">
                        <DecorativeBackground type="income" />
                        <span className="relative z-10 text-[10px] font-black text-emerald-500 uppercase tracking-[0.3em] block mb-2">Total Receitas</span>
                        <h3 className="relative z-10 text-4xl font-black tracking-tighter text-white">{formatCurrency(dashboardStats.totalIncome)}</h3>
                      </div>
                      <div className="bg-slate-900/40 p-10 rounded-[2.5rem] border border-white/5 shadow-2xl relative overflow-hidden group">
                        <DecorativeBackground type="expense" />
                        <span className="relative z-10 text-[10px] font-black text-rose-500 uppercase tracking-[0.3em] block mb-2">Total Despesas</span>
                        <h3 className="relative z-10 text-4xl font-black tracking-tighter text-white">{formatCurrency(dashboardStats.totalExpense)}</h3>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                      <div className="lg:col-span-8 bg-slate-900/40 p-10 rounded-[2.5rem] border border-white/5 shadow-2xl relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-12 opacity-[0.02] pointer-events-none">
                           <TrendingUp size={200} className="text-white" />
                        </div>
                        <div className="flex items-center justify-between mb-10 relative z-10">
                          <div>
                            <h4 className="text-[10px] font-black text-white uppercase tracking-[0.3em] flex items-center gap-2">
                              <TrendingUp size={16} className="text-emerald-500" /> Análise Anual
                            </h4>
                            <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mt-1">Evolução Real do Fluxo de Caixa</p>
                          </div>
                          <div className="flex items-center gap-2 bg-slate-950/50 p-1 rounded-xl border border-white/5">
                            <button onClick={() => setSelectedYear(y => y - 1)} className="p-1.5 hover:bg-white/5 rounded-lg text-slate-500"><ChevronLeft size={14}/></button>
                            <span className="text-[9px] font-black text-slate-300 uppercase px-2 w-12 text-center">{selectedYear}</span>
                            <button onClick={() => setSelectedYear(y => y + 1)} className="p-1.5 hover:bg-white/5 rounded-lg text-slate-500"><ChevronRight size={14}/></button>
                          </div>
                        </div>
                        <div className="relative z-10">
                          <MonthlyBarChart data={yearlyHistory} />
                        </div>
                      </div>

                      <div className="lg:col-span-4 bg-slate-900/40 p-10 rounded-[2.5rem] border border-white/5 shadow-2xl flex flex-col items-center justify-between h-full">
                        <h4 className="text-[10px] font-black text-white uppercase tracking-[0.3em] mb-8 text-center">Distribuição</h4>
                        <div className="flex-1 flex items-center justify-center w-full">
                          <DonutChart 
                            data={Object.entries((transactions || []).filter(t => t.type === 'expense' && String(t.date || "").includes(selectedMonth)).reduce((acc: any, t) => { const cat = t.category || 'Outros'; acc[cat] = (acc[cat] || 0) + t.amount; return acc; }, {})).map(([name, value]) => ({ name, value: value as number }))} 
                            colors={DASHBOARD_COLORS} 
                          />
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                      <div className="bg-slate-900/40 p-10 rounded-[2.5rem] border border-white/5 shadow-2xl relative overflow-hidden">
                        <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-indigo-500/5 rounded-full blur-[60px]" />
                        <h4 className="text-[10px] font-black text-white uppercase tracking-[0.3em] mb-10 flex items-center gap-2 relative z-10">
                          <Smartphone size={16} className="text-indigo-500" /> Detalhamento de Despesas
                        </h4>
                        <div className="relative z-10">
                          <CategoryBarChart 
                            data={Object.entries((transactions || []).filter(t => t.type === 'expense' && String(t.date || "").includes(selectedMonth)).reduce((acc: any, t) => { const cat = t.category || 'Outros'; acc[cat] = (acc[cat] || 0) + t.amount; return acc; }, {})).map(([name, value]) => ({ name, value: value as number }))} 
                            colors={DASHBOARD_COLORS} 
                          />
                        </div>
                      </div>

                      <div className="bg-slate-900/40 p-10 rounded-[2.5rem] border border-white/5 shadow-2xl flex flex-col justify-center relative overflow-hidden">
                         <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-gradient-to-br from-emerald-500/5 via-transparent to-rose-500/5 opacity-40 pointer-events-none" />
                         <div className="text-center space-y-12 relative z-10">
                            <h4 className="text-[10px] font-black text-white uppercase tracking-[0.3em] mb-4">Eficiência de Caixa</h4>
                            <div className="space-y-6">
                               <div className="flex justify-between items-end px-2">
                                  <div>
                                    <span className="text-[9px] font-black text-slate-500 uppercase block text-left">Giro Mensal</span>
                                    <span className="text-2xl font-black text-white tracking-tighter">{formatCurrency(dashboardStats.totalIncome + dashboardStats.totalExpense)}</span>
                                  </div>
                                  <div className="text-right">
                                    <span className="text-[9px] font-black text-slate-500 uppercase block">Taxa de Poupança</span>
                                    <span className={`text-2xl font-black tracking-tighter ${dashboardStats.balance > 0 ? 'text-emerald-400' : 'text-rose-500'}`}>
                                      {dashboardStats.totalIncome > 0 ? ((dashboardStats.balance / dashboardStats.totalIncome) * 100).toFixed(1) : 0}%
                                    </span>
                                  </div>
                               </div>
                               <div className="h-4 w-full bg-slate-950 rounded-full overflow-hidden flex shadow-inner border border-white/5 p-1">
                                  <div className="h-full bg-emerald-500 rounded-full transition-all duration-1000 shadow-[0_0_15px_rgba(16,185,129,0.2)]" style={{ width: `${(dashboardStats.totalIncome / (dashboardStats.totalIncome + dashboardStats.totalExpense + 0.001)) * 100}%` }} />
                                  <div className="h-full bg-rose-500 rounded-full transition-all duration-1000 shadow-[0_0_15px_rgba(244,63,94,0.2)] ml-1" style={{ width: `${(dashboardStats.totalExpense / (dashboardStats.totalIncome + dashboardStats.totalExpense + 0.001)) * 100}%` }} />
                               </div>
                               <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pt-4">Você está retendo {dashboardStats.balance > 0 ? ((dashboardStats.balance / dashboardStats.totalIncome) * 100).toFixed(0) : 0}% do seu capital mensalmente.</p>
                            </div>
                         </div>
                      </div>
                    </div>
                  </div>
                )}

                {(activeTab === 'transactions' || activeTab === 'fixed') && (
                  <div className="bg-[#0f172a]/40 border border-white/5 rounded-[2rem] overflow-hidden shadow-xl">
                    <div className="p-6 border-b border-white/5 bg-slate-900/40 flex items-center justify-between">
                       <h4 className="text-[10px] font-black uppercase text-slate-400 tracking-widest flex items-center gap-2">
                        {activeTab === 'fixed' ? <Repeat size={14} className="text-indigo-400"/> : <Wallet size={14} className="text-emerald-400"/>}
                        {activeTab === 'fixed' ? 'Contas Fixas' : 'Lançamentos Variáveis'}
                       </h4>
                       <span className="text-[8px] font-black bg-white/5 px-2.5 py-1 rounded-lg">{(currentTabTrans || []).length} Registros</span>
                    </div>
                    <div className="divide-y divide-white/5">
                      {(currentTabTrans || []).map(t => (
                        <div key={t.id} className="p-4 md:p-5 flex flex-row items-center justify-between hover:bg-white/[0.02] group transition-all">
                          <div className="flex items-center gap-4 min-w-0">
                            <div className={`p-2.5 rounded-xl border flex-shrink-0 ${t.type === 'income' ? 'text-emerald-500 border-emerald-500/20 bg-emerald-500/5' : 'text-rose-500 border-rose-500/20 bg-rose-500/5'}`}>
                              {t.type === 'income' ? <ArrowUpCircle size={18} /> : <ArrowDownCircle size={18} />}
                            </div>
                            <div className="min-w-0">
                              <p className="text-sm font-bold text-white uppercase truncate tracking-tight">{t.description}</p>
                              <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest flex gap-2">
                                <span>{t.date || 'Mensal'}</span> • <span className="truncate">{t.category}</span>
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-4 ml-4">
                            <span className={`font-black text-lg font-mono ${t.type === 'income' ? 'text-emerald-400' : 'text-rose-400'}`}>{formatCurrency(t.amount)}</span>
                            <button onClick={() => deleteTransaction(t.id, activeTab === 'fixed')} className="p-2 text-slate-700 hover:text-rose-500 opacity-0 md:group-hover:opacity-100 transition-all"><Trash2 size={16} /></button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === 'calculator' && <CalculatorContent />}
                
                {activeTab === 'driver-panel' && (
                  <div className="space-y-12 pb-20">
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
                       <div>
                          <h2 className="text-3xl font-black uppercase text-white tracking-tighter leading-none">Performance do <span className="text-amber-400">Motorista</span></h2>
                          <p className="text-[8px] font-bold text-slate-500 uppercase tracking-widest mt-2">
                            {driverMode} - {driverMode === 'DIARIO' ? selectedDay : selectedMonth}
                          </p>
                       </div>
                       <div className="flex gap-1 bg-slate-900/50 p-1.5 rounded-2xl border border-white/5">
                          {['DIARIO', 'MENSAL'].map(m => (
                            <button key={m} onClick={() => setDriverMode(m as any)} className={`px-6 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${driverMode === m ? 'bg-amber-500 text-slate-950 shadow-lg' : 'text-slate-500 hover:text-white'}`}>{m}</button>
                          ))}
                       </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="bg-emerald-500 p-8 rounded-[2.5rem] text-slate-950 shadow-2xl relative overflow-hidden group border-b-8 border-emerald-600">
                        <TrendingUp size={100} className="absolute -bottom-6 -right-6 opacity-10 group-hover:scale-110 transition-transform" />
                        <span className="text-[10px] font-black uppercase tracking-widest opacity-60 block">Ganhos Brutos</span>
                        <h3 className="text-4xl font-black mt-2 tracking-tighter">{formatCurrency(driverStats.totalAmount)}</h3>
                      </div>
                      <div className="bg-rose-500 p-8 rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden group border-b-8 border-rose-700">
                        <ArrowDownCircle size={100} className="absolute -bottom-6 -right-6 opacity-10 group-hover:scale-110 transition-transform" />
                        <span className="text-[10px] font-black uppercase tracking-widest opacity-60 block">Gastos Totais</span>
                        <h3 className="text-4xl font-black mt-2 tracking-tighter">{formatCurrency(driverStats.totalCost)}</h3>
                      </div>
                      <div className="bg-amber-400 p-8 rounded-[2.5rem] text-slate-950 shadow-2xl relative overflow-hidden group border-b-8 border-amber-600">
                        <Check size={100} className="absolute -bottom-6 -right-6 opacity-10 group-hover:scale-110 transition-transform" />
                        <span className="text-[10px] font-black uppercase tracking-widest opacity-60 block">Lucro Líquido</span>
                        <h3 className="text-4xl font-black mt-2 tracking-tighter">{formatCurrency(driverStats.netProfit)}</h3>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                       <div className="bg-slate-900/40 p-10 rounded-[2.5rem] border border-white/5 shadow-xl">
                          <h4 className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-8 border-b border-white/5 pb-4">Ganhos por Plataforma</h4>
                          <div className="space-y-4">
                             {Object.entries(driverStats.appBreakdown).map(([app, value]) => (
                               <div key={app} className="flex flex-col gap-2">
                                  <div className="flex justify-between items-end">
                                     <span className="text-xs font-black uppercase text-white">{app}</span>
                                     <span className="text-sm font-mono text-slate-400">{formatCurrency(value as number)}</span>
                                  </div>
                                  <div className="h-2 bg-slate-950 rounded-full overflow-hidden">
                                     <div className={`h-full transition-all duration-1000 ${app === 'Uber' ? 'bg-black border border-white/20' : app === '99' ? 'bg-amber-400' : 'bg-indigo-500'}`} style={{ width: `${((value as number) / (driverStats.totalAmount || 1)) * 100}%` }} />
                                  </div>
                               </div>
                             ))}
                          </div>
                       </div>

                       <div className="bg-slate-900/40 p-10 rounded-[2.5rem] border border-white/5 shadow-xl grid grid-cols-2 gap-8 content-center">
                          <div className="text-center">
                             <Clock className="mx-auto text-slate-500 mb-2" size={24} />
                             <span className="text-[8px] font-black uppercase text-slate-500">Tempo Online</span>
                             <p className="text-2xl font-black text-white">{driverStats.formattedHours}</p>
                          </div>
                          <div className="text-center">
                             <MapPin className="mx-auto text-slate-500 mb-2" size={24} />
                             <span className="text-[8px] font-black uppercase text-slate-500">Distância Total</span>
                             <p className="text-2xl font-black text-white">{driverStats.totalKm} <span className="text-xs text-slate-500 uppercase">KM</span></p>
                          </div>
                          <div className="text-center">
                             <Coins className="mx-auto text-emerald-500 mb-2" size={24} />
                             <span className="text-[8px] font-black uppercase text-slate-500">Média p/ KM</span>
                             <p className="text-2xl font-black text-emerald-400">{formatCurrency(driverStats.metrics.lucroPorKm)}</p>
                          </div>
                          <div className="text-center">
                             <Zap className="mx-auto text-amber-400 mb-2" size={24} />
                             <span className="text-[8px] font-black uppercase text-slate-500">Média p/ Hora</span>
                             <p className="text-2xl font-black text-amber-400">{formatCurrency(driverStats.metrics.lucroPorHora)}</p>
                          </div>
                       </div>
                    </div>

                    <div className="bg-slate-900/40 border border-white/5 rounded-[2.5rem] overflow-hidden">
                       <div className="p-8 border-b border-white/5 bg-slate-900/60 flex items-center justify-between">
                          <h4 className="text-[10px] font-black uppercase text-slate-400 tracking-widest flex items-center gap-2">Histórico de Corridas</h4>
                          <span className="text-[8px] font-black bg-white/5 px-2.5 py-1 rounded-lg">{(currentMonthSessions || []).length} Sessões</span>
                       </div>
                       <div className="divide-y divide-white/5">
                          {(currentMonthSessions || []).map(s => (
                            <div key={s.id} className="p-6 flex items-center justify-between hover:bg-white/[0.02] group transition-all">
                               <div className="flex items-center gap-6 min-w-0">
                                  <div className={`p-4 rounded-2xl font-black text-xs ${s.app === 'Uber' ? 'bg-black border border-white/10 text-white' : s.app === '99' ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-400'}`}>
                                     {s.app.charAt(0)}
                                  </div>
                                  <div className="min-w-0">
                                     <h5 className="text-base font-black uppercase text-white leading-none">{s.app} • {new Date(s.date).toLocaleDateString('pt-BR')}</h5>
                                     <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mt-2">
                                        {s.trips} viagens • {s.km_driven} km • {s.hours_worked}h
                                     </p>
                                  </div>
                               </div>
                               <div className="flex items-center gap-6">
                                  <div className="text-right">
                                     <p className="text-xl font-black text-emerald-400">{formatCurrency(s.amount)}</p>
                                     <p className="text-[8px] font-black text-rose-500 uppercase">Gastos: {formatCurrency((s.fuel_spent || 0) + (s.food_spent || 0) + (s.other_spent || 0))}</p>
                                  </div>
                                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-all">
                                     <button onClick={() => { setSelectedDriverSession(s); setModals(m => ({ ...m, driver: true })); }} className="p-2.5 bg-slate-800 rounded-xl text-slate-400 hover:text-white transition-all"><Edit3 size={16}/></button>
                                     <button onClick={() => deleteDriver(s.id)} className="p-2.5 bg-rose-500/10 rounded-xl text-rose-500/40 hover:text-rose-500 transition-all"><Trash2 size={16}/></button>
                                  </div>
                               </div>
                            </div>
                          ))}
                       </div>
                    </div>
                  </div>
                )}

                {activeTab === 'shopping' && (
                  <div className="bg-slate-900/40 border border-white/5 rounded-[2.5rem] overflow-hidden shadow-2xl">
                    <div className="p-8 border-b border-white/5 bg-slate-900/60 flex flex-col md:flex-row justify-between items-center gap-6">
                       <div className="flex items-center gap-4">
                          <div className="p-4 bg-amber-500 text-slate-950 rounded-[1.5rem]"><ShoppingCart size={24} /></div>
                          <h4 className="text-xl font-black uppercase text-white tracking-tight">Lista de Compras</h4>
                       </div>
                       <div className="bg-slate-950/50 px-8 py-4 rounded-[2rem] border border-white/5 text-center shadow-inner">
                          <span className="text-[10px] font-black text-slate-500 uppercase block mb-1">Custo Estimado</span>
                          <span className="text-3xl font-black text-amber-400 font-mono tracking-tighter">{formatCurrency((shoppingList || []).reduce((acc, i) => acc + (i.estimated_price * i.quantity), 0))}</span>
                       </div>
                    </div>
                    <div className="divide-y divide-white/5">
                      {(shoppingList || []).map(item => (
                        <div key={item.id} className="p-5 md:p-6 flex items-center justify-between hover:bg-white/[0.02] group transition-all">
                          <div className="flex items-center gap-6 min-0">
                            <button onClick={() => toggleShop(item)} className={`p-4 rounded-2xl transition-all border-2 ${item.completed ? 'bg-emerald-500 border-emerald-400 text-slate-950' : 'bg-slate-800 border-slate-700 text-slate-600'}`}>
                              {item.completed ? <CheckSquare size={22} /> : <Square size={22} />}
                            </button>
                            <div className="min-w-0">
                              <h5 className={`text-lg font-black uppercase truncate tracking-tight ${item.completed ? 'line-through text-slate-600' : 'text-white'}`}>{item.name}</h5>
                              <p className="text-[9px] font-black text-slate-500 uppercase">{item.quantity} {item.unit} • {formatCurrency(item.estimated_price)} p/ un</p>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <button onClick={() => { setSelectedItem(item); setModals(m => ({ ...m, price: true })); }} className="px-4 py-2 bg-slate-800 rounded-xl text-[9px] font-black uppercase text-slate-400 hover:text-white transition-all border border-white/5">Preço</button>
                            <button onClick={async () => { if(window.confirm("Remover item da lista?")) { await deleteShop(item.id); } }} className="p-2.5 text-rose-500/40 hover:text-rose-500 transition-all"><Trash2 size={20} /></button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === 'goals' && (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {(goals || []).map(goal => {
                      const progress = Math.min((goal.current_amount / (goal.target_amount || 1)) * 100, 100);
                      const isCompleted = progress >= 100;
                      return (
                        <div key={goal.id} className={`bg-slate-900/40 border ${isCompleted ? 'border-emerald-500/30 shadow-[0_0_30px_rgba(16,185,129,0.05)]' : 'border-white/5'} p-8 rounded-[2.5rem] shadow-xl relative group transition-all hover:scale-[1.02]`}>
                          <div className="absolute top-8 right-8 transition-all duration-500">
                            {isCompleted ? (
                              <Trophy className="text-amber-400 drop-shadow-[0_0_8px_rgba(251,191,36,0.4)]" size={32} />
                            ) : (
                              <Target className="text-slate-700" size={32} />
                            )}
                          </div>
                          <h4 className={`text-xl font-black uppercase tracking-tight truncate pr-14 ${isCompleted ? 'text-emerald-400' : 'text-white'}`}>{goal.description}</h4>
                          <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mt-2 mb-8 bg-slate-950/50 w-fit px-3 py-1 rounded-lg">Alvo: {goal.type === 'financial' ? formatCurrency(goal.target_amount) : `${goal.target_amount}`}</p>
                          <div className="space-y-4">
                            <div className="flex justify-between items-end">
                              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Progresso</span>
                              <span className={`text-sm font-black ${isCompleted ? 'text-emerald-400' : 'text-slate-200'}`}>{progress.toFixed(0)}%</span>
                            </div>
                            <div className="h-3 bg-slate-800 rounded-full overflow-hidden p-0.5 border border-white/5 shadow-inner">
                              <div className={`h-full rounded-full transition-all duration-1000 ${isCompleted ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]' : (goal.type === 'financial' ? 'bg-emerald-500/60' : 'bg-indigo-500/60')}`} style={{ width: `${progress}%` }} />
                            </div>
                          </div>
                          <div className="flex gap-3 mt-8">
                            <button 
                              onClick={() => { setSelectedGoal(goal); setModals(m => ({ ...m, aporte: true })); }} 
                              disabled={isCompleted}
                              className={`flex-1 ${isCompleted ? 'bg-slate-800 text-slate-500 cursor-not-allowed' : 'bg-emerald-500 text-slate-950'} py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg transition-all active:scale-95`}
                            >
                              {isCompleted ? 'Concluída' : 'Aportar'}
                            </button>
                            <button 
                              onClick={async () => { if(window.confirm("Excluir meta estratégica?")) { await deleteGoal(goal.id); } }} 
                              className="p-3 bg-rose-500/10 rounded-xl text-rose-500/40 hover:text-rose-500 hover:bg-rose-500/20 transition-all"
                            >
                              <Trash2 size={20} />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </main>

      <DataCenterModal isOpen={modals.dataCenter} onClose={() => setModals(m => ({ ...m, dataCenter: false }))} transactions={transactions || []} selectedMonth={selectedMonth} onImport={handleImportData} />
      <TransactionModal isOpen={modals.transaction} onClose={() => setModals(m => ({ ...m, transaction: false }))} onSubmit={async (data) => { 
          const table = data.is_fixed ? 'fixed_transactions' : 'transactions';
          const { error } = await api.transactions.upsert(table, { ...data, user_id: user?.id }); 
          if(error) { notify(error.message, 'error'); return false; } 
          data.is_fixed ? await fetchFixed() : await fetchTransactions(); 
          notify('Lançamento registrado!'); return true; 
        }} />
      <GoalModal isOpen={modals.goal} onClose={() => setModals(m => ({ ...m, goal: false }))} onSubmit={async (data) => { 
          const { error } = await supabase.from('goals').insert({ ...data, user_id: user?.id }); 
          if(error) { notify(error.message, 'error'); return false; } 
          await fetchGoals(); notify('Meta estratégica criada!'); return true; 
        }} />
      <AporteModal isOpen={modals.aporte} onClose={() => setModals(m => ({ ...m, aporte: false }))} goal={selectedGoal} onSubmit={async (val) => { 
          if (!selectedGoal) return false; const { error } = await supabase.from('goals').update({ current_amount: selectedGoal.current_amount + val }).eq('id', selectedGoal.id); 
          if (error) { notify(error.message, 'error'); return false; } await fetchGoals(); notify("Progresso atualizado!"); return true; 
        }} />
      <ShoppingModal isOpen={modals.shop} onClose={() => setModals(m => ({ ...m, shop: false }))} onSubmit={async (data) => addShop(data)} />
      <UpdatePriceModal isOpen={modals.price} onClose={() => setModals(m => ({ ...m, price: false }))} itemName={selectedItem?.name || ''} onSubmit={async (price) => { 
          if (!selectedItem) return false; const { error } = await supabase.from('shopping_items').update({ estimated_price: price }).eq('id', selectedItem.id); 
          if (error) { notify(error.message, 'error'); return false; } await fetchShopping(); notify("Preço unitário definido!"); return true; 
        }} />
      <DriverModal isOpen={modals.driver} onClose={() => { setModals(m => ({ ...m, driver: false })); setSelectedDriverSession(null); }} initialData={selectedDriverSession} onSubmit={async (data) => {
          if (selectedDriverSession) {
             const { error } = await supabase.from('driver_sessions').update(data).eq('id', selectedDriverSession.id);
             if (error) { notify(error.message, 'error'); return false; }
             notify('Sessão atualizada!'); await fetchDriver(); return true;
          } else { return addDriver(data); }
        }} />
    </div>
  );
};

const App = () => (<AuthProvider><AppContent /></AuthProvider>);
export default App;
