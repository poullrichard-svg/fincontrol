
/**
 * Utilitários de Cálculo Financeiro de Alta Precisão
 * Desenvolvido por Engenharia de Software e Matemática Financeira
 */

export interface CompoundInterestInput {
  initialAmount: number;
  monthlyContribution: number;
  annualRate: number;
  years: number;
}

export interface DriverInput {
  carType: 'owned' | 'financed' | 'rented';
  monthlyKm: number;
  fuelPrice: number;
  fuelEfficiency: number;
  monthlyRent?: number;
  carInstallment?: number;
  insurance?: number;
  ipvaAnnual?: number;
  desiredNetIncome: number;
  maintenancePerKm?: number;
  depreciationMonthly?: number;
  interestRate?: number; // Annual interest rate for financing
}

export const round = (num: number) => Math.round((num + Number.EPSILON) * 100) / 100;

/**
 * A) Calcula Juros Compostos com extrato mensal
 */
export const calculateCompoundInterest = (input: CompoundInterestInput) => {
  const { initialAmount, monthlyContribution, annualRate, years } = input;
  const monthlyRate = Math.pow(1 + annualRate / 100, 1 / 12) - 1;
  const totalMonths = years * 12;
  
  let currentBalance = initialAmount;
  let totalInvested = initialAmount;
  const monthlyBreakdown = [];

  for (let m = 1; m <= totalMonths; m++) {
    const interestEarned = currentBalance * monthlyRate;
    currentBalance += interestEarned + monthlyContribution;
    totalInvested += monthlyContribution;
    
    if (m % 12 === 0 || m === totalMonths) {
      monthlyBreakdown.push({
        month: m,
        year: m / 12,
        balance: round(currentBalance),
        invested: round(totalInvested)
      });
    }
  }

  return {
    totalInvested: round(totalInvested),
    totalInterest: round(currentBalance - totalInvested),
    finalAmount: round(currentBalance),
    monthlyBreakdown
  };
};

/**
 * B) Jornada do Milhão (Do 0 ao Milhão)
 */
export const calculateMillionJourney = (contribution: number, annualRate: number, targetYears?: number) => {
  const target = 1000000;
  const r = Math.pow(1 + annualRate / 100, 1 / 12) - 1;
  
  let monthsToMillion = 0;
  if (r <= 0) {
    monthsToMillion = target / (contribution || 1);
  } else {
    monthsToMillion = Math.log((target * r + (contribution || 1)) / (contribution || 1)) / Math.log(1 + r);
  }

  const nYears = targetYears || 10;
  const totalMonths = nYears * 12;
  const requiredContribution = (target * r) / (Math.pow(1 + r, totalMonths) - 1);

  return {
    monthsToMillion: Math.ceil(monthsToMillion),
    yearsToMillion: round(monthsToMillion / 12),
    requiredContributionForTargetYears: round(requiredContribution),
    targetYears: nYears
  };
};

/**
 * C) Reserva de Emergência
 */
export const calculateEmergencyFund = (monthlyExpenses: number, jobType: 'public' | 'clt' | 'autonomous') => {
  const multipliers = {
    public: 3,
    clt: 6,
    autonomous: 12
  };
  const factor = multipliers[jobType];
  return {
    targetAmount: round(monthlyExpenses * factor),
    monthsRequired: factor
  };
};

/**
 * D) Métricas para Motoristas de App (Uber/99)
 */
export const calculateDriverMetrics = (input: DriverInput) => {
  const { 
    carType, monthlyKm, fuelPrice, fuelEfficiency, 
    monthlyRent = 0, carInstallment = 0, insurance = 0, 
    ipvaAnnual = 0, desiredNetIncome, maintenancePerKm = 0.15,
    depreciationMonthly = 0, interestRate = 0
  } = input;

  // 1. Custos Fixos
  let fixedCosts = 0;
  if (carType === 'rented') {
    fixedCosts = monthlyRent;
  } else if (carType === 'financed') {
    // Cálculo simplificado de juros sobre a parcela (ou saldo, aqui simulamos sobre a parcela para simplicidade do formulário)
    const monthlyInterest = interestRate > 0 ? (carInstallment * (interestRate / 100 / 12)) : 0;
    fixedCosts = carInstallment + monthlyInterest + (insurance / 12) + (ipvaAnnual / 12) + depreciationMonthly;
  } else {
    fixedCosts = (insurance / 12) + (ipvaAnnual / 12) + depreciationMonthly; 
  }

  // 2. Custos Variáveis
  const fuelCostPerKm = fuelPrice / (fuelEfficiency || 1);
  const totalVariableCost = (fuelCostPerKm + maintenancePerKm) * monthlyKm;
  
  // 3. Cálculos Finais
  const totalMonthlyCost = fixedCosts + totalVariableCost;
  const requiredGrossRevenue = totalMonthlyCost + desiredNetIncome;
  
  const minPricePerKm = requiredGrossRevenue / (monthlyKm || 1);
  const avgSpeed = 25; // km/h médio urbano
  const minPricePerHour = requiredGrossRevenue / (monthlyKm / avgSpeed);

  return {
    fixedCosts: round(fixedCosts),
    variableCosts: round(totalVariableCost),
    totalMonthlyCost: round(totalMonthlyCost),
    requiredGrossRevenue: round(requiredGrossRevenue),
    minPricePerKm: round(minPricePerKm),
    minPricePerHour: round(minPricePerHour)
  };
};

/**
 * E) Simulação de Amortização
 */
export const calculateAmortizationSimulation = (debtAmount: number, installment: number, extraPayment: number) => {
  const originalMonths = Math.ceil(debtAmount / (installment || 1));
  const newDebt = Math.max(0, debtAmount - extraPayment);
  const remainingMonths = Math.ceil(newDebt / (installment || 1));
  
  return {
    monthsSaved: originalMonths - remainingMonths,
    remainingMonths,
    debtReducedPercent: round((extraPayment / debtAmount) * 100)
  };
};
