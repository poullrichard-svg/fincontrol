
export const round = (num: number) => Math.round((num + Number.EPSILON) * 100) / 100;

export const formatCurrency = (val: number | string) => {
  const amount = Number(val);
  if (isNaN(amount)) return "R$ 0,00";
  return amount.toLocaleString('pt-BR', { 
    style: 'currency', 
    currency: 'BRL',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
};

export const formatDisplayAmount = (raw: string) => {
  const number = (parseInt(raw) || 0) / 100;
  return number.toLocaleString('pt-BR', { 
    style: 'currency', 
    currency: 'BRL',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
};

/**
 * detectDelimiter: Detecta automaticamente o delimitador de um CSV
 */
export const detectDelimiter = (text: string): string => {
  const firstLine = text.split('\n')[0];
  const counts = {
    ',': (firstLine.match(/,/g) || []).length,
    ';': (firstLine.match(/;/g) || []).length,
    '\t': (firstLine.match(/\t/g) || []).length
  };
  if (counts[';'] > counts[','] && counts[';'] > counts['\t']) return ';';
  if (counts['\t'] > counts[','] && counts['\t'] > counts[';']) return '\t';
  return ',';
};

/**
 * normalizeHeader: Remove acentos, trim, lowercase e substitui espaços por sublinhados
 */
export const normalizeHeader = (h: string): string => {
  return h
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .replace(/\s+/g, '_');
};

/**
 * parseBRDateToISO: Converte DD/MM/AAAA ou DD-MM-AAAA para YYYY-MM-DD
 */
export const parseBRDateToISO = (str: string): string | null => {
  if (!str) return null;
  const clean = str.trim().replace(/-/g, '/');
  const parts = clean.split('/');
  
  if (parts.length === 3) {
    let day, month, year;
    // Checa se é YYYY/MM/DD ou DD/MM/YYYY
    if (parts[0].length === 4) {
      [year, month, day] = parts;
    } else {
      [day, month, year] = parts;
    }
    
    if (!day || !month || !year) return null;

    const y = year.length === 2 ? `20${year}` : year;
    const m = month.padStart(2, '0');
    const d = day.padStart(2, '0');
    
    // Validação básica de data
    const date = new Date(`${y}-${m}-${d}T12:00:00Z`);
    if (isNaN(date.getTime())) return null;

    return `${y}-${m}-${d}`;
  }
  return null;
};

/**
 * parseMoneyBR: Lógica robusta para moedas BR e internacionais
 * Suporta: 1.234,56 | 1234,56 | 1234.56 | -5.72
 */
export const parseMoneyBR = (raw: any): number => {
  if (typeof raw === 'number') return raw;
  if (!raw) return 0;
  
  let s = String(raw).replace(/[R$\s]/g, '');
  
  const hasComma = s.includes(',');
  const hasDot = s.includes('.');

  if (hasComma && hasDot) {
    // Caso 1.234,56 ou 1,234.56
    // Se a vírgula vier depois do ponto, é BR (1.000,00)
    if (s.indexOf(',') > s.indexOf('.')) {
      s = s.replace(/\./g, '').replace(',', '.');
    } else {
      // Caso US (1,000.00)
      s = s.replace(/,/g, '');
    }
  } else if (hasComma) {
    // Caso 1000,00 -> Troca vírgula por ponto
    s = s.replace(',', '.');
  }
  // Se for apenas ponto (1000.00), parseFloat já entende.

  const result = parseFloat(s);
  return isNaN(result) ? 0 : result;
};
