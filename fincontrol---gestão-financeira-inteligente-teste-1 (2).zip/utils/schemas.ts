
import { z } from 'zod';

export const TransactionSchema = z.object({
  description: z.string().min(3, "Descrição muito curta").max(50),
  amount: z.number().positive("O valor deve ser maior que zero"),
  type: z.enum(['income', 'expense']),
  category: z.string().min(1, "Selecione uma categoria"),
  payment_method: z.string().optional().default('Pix'),
  date: z.string().nullable().optional(),
  is_fixed: z.boolean().optional(),
  external_id: z.string().nullable().optional()
});

export const DriverSessionSchema = z.object({
  date: z.string().min(1, "Data é obrigatória"),
  app: z.enum(['Uber', '99', 'InDrive', 'Particular']),
  amount: z.number().nonnegative("Ganhos não podem ser negativos"),
  trips: z.number().int().nonnegative(),
  km_driven: z.number().nonnegative("KM não pode ser negativo"),
  hours_worked: z.string().regex(/^\d{2}:\d{2}$/, "Formato de hora inválido"),
  fuel_spent: z.number().nonnegative().optional().default(0),
  food_spent: z.number().nonnegative().optional().default(0),
  other_spent: z.number().nonnegative().optional().default(0),
  observation: z.string().nullable().optional()
});

export const GoalSchema = z.object({
  description: z.string().min(3, "Descrição muito curta"),
  target_amount: z.number().positive("Valor alvo deve ser positivo"),
  current_amount: z.number().nonnegative("Valor atual não pode ser negativo"),
  type: z.enum(['financial', 'activity']),
  unit: z.string().optional().default('R$'),
  deadline: z.string().optional()
});

export const ShoppingItemSchema = z.object({
  name: z.string().min(2, "Nome do item muito curto"),
  quantity: z.number().positive(),
  unit: z.string().min(1),
  estimated_price: z.number().nonnegative(),
  completed: z.boolean().default(false)
});

export type TransactionInput = z.infer<typeof TransactionSchema>;
export type DriverSessionInput = z.infer<typeof DriverSessionSchema>;
export type GoalInput = z.infer<typeof GoalSchema>;
export type ShoppingInput = z.infer<typeof ShoppingItemSchema>;
