
import { Transaction, DriverSession, DriverApp } from '../types';
import { round } from './format';

export const calculateDashboardStats = (
  transactions: Transaction[], 
  fixedTransactions: Transaction[], 
  selectedMonth: string
) => {
  const currentMonthTrans = transactions.filter(t => {
    const dateStr = String(t.date || "");
    return dateStr.includes(selectedMonth);
  });
  
  const varIncome = currentMonthTrans
    .filter(t => t.type === 'income')
    .reduce((acc, t) => acc + (t.amount || 0), 0);
    
  const varExpense = currentMonthTrans
    .filter(t => t.type === 'expense')
    .reduce((acc, t) => acc + (t.amount || 0), 0);
    
  const fixIncome = fixedTransactions
    .filter(t => t.type === 'income')
    .reduce((acc, t) => acc + (t.amount || 0), 0);
    
  const fixExpense = fixedTransactions
    .filter(t => t.type === 'expense')
    .reduce((acc, t) => acc + (t.amount || 0), 0);

  const totalIncome = round(varIncome + fixIncome);
  const totalExpense = round(varExpense + fixExpense);

  return {
    totalIncome,
    totalExpense,
    balance: round(totalIncome - totalExpense)
  };
};

/**
 * Calcula o histórico anual real baseado nos dados do Supabase para um ano específico
 */
export const calculateYearlyHistory = (
  transactions: Transaction[],
  fixedTransactions: Transaction[],
  year: number
) => {
  const months = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
  
  const fixIncome = fixedTransactions.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0);
  const fixExpense = fixedTransactions.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0);

  return months.map((monthName, index) => {
    const monthIndex = (index + 1).toString().padStart(2, '0');
    const monthPattern = `${year}-${monthIndex}`;
    
    const monthTrans = transactions.filter(t => String(t.date || "").includes(monthPattern));
    
    const varIncome = monthTrans.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0);
    const varExpense = monthTrans.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0);

    return {
      month: monthName,
      income: round(varIncome + fixIncome),
      expense: round(varExpense + fixExpense)
    };
  });
};

export const calculateDriverPerformance = (
  sessions: DriverSession[], 
  transactions: Transaction[],
  fixedTransactions: Transaction[],
  selectedMonth: string,
  selectedDay: string,
  timeframe: 'diario' | 'mensal'
) => {
  const activeSessions = sessions.filter(s => {
    const dateStr = String(s.date || "");
    return timeframe === 'diario' ? dateStr === selectedDay : dateStr.includes(selectedMonth);
  });

  const totalAmount = activeSessions.reduce((acc, s) => acc + (s.amount || 0), 0);
  const totalTrips = activeSessions.reduce((acc, s) => acc + (s.trips || 0), 0);
  const totalKm = activeSessions.reduce((acc, s) => acc + (s.km_driven || 0), 0);
  const totalFuel = activeSessions.reduce((acc, s) => acc + (s.fuel_spent || 0), 0);
  const totalFood = activeSessions.reduce((acc, s) => acc + (s.food_spent || 0), 0);

  const appBreakdown: Record<DriverApp, number> = {
    'Uber': 0,
    '99': 0,
    'InDrive': 0,
    'Particular': 0
  };
  activeSessions.forEach(s => {
    if (appBreakdown[s.app] !== undefined) {
      appBreakdown[s.app] += s.amount;
    }
  });

  let totalMinutes = 0;
  activeSessions.forEach(s => {
    if (s.hours_worked) {
      const [h, m] = s.hours_worked.split(':').map(Number);
      totalMinutes += (h || 0) * 60 + (m || 0);
    }
  });

  const hoursDecimal = totalMinutes / 60;
  
  const expenses = transactions.filter(t => {
    if (t.type !== 'expense') return false;
    const isDriverCat = ['Transporte', 'Alimentação', 'Combustível'].includes(t.category);
    const dateStr = String(t.date || "");
    const isInPeriod = timeframe === 'diario' ? dateStr === selectedDay : dateStr.includes(selectedMonth);
    return isDriverCat && isInPeriod;
  }).reduce((acc, t) => acc + (t.amount || 0), 0);

  const fixedCosts = timeframe === 'mensal' 
    ? fixedTransactions.filter(t => t.type === 'expense' && t.category === 'Transporte').reduce((acc, t) => acc + (t.amount || 0), 0)
    : 0;

  const totalCost = round(expenses + fixedCosts + totalFuel + totalFood);
  const netProfit = round(totalAmount - totalCost);

  return {
    totalAmount,
    totalTrips,
    totalKm,
    totalFuel,
    totalFood,
    appBreakdown,
    formattedHours: `${Math.floor(totalMinutes/60).toString().padStart(2, '0')}:${(totalMinutes%60).toString().padStart(2, '0')}`,
    netProfit,
    totalCost,
    metrics: {
      lucroPorHora: hoursDecimal > 0 ? netProfit / hoursDecimal : 0,
      lucroPorKm: totalKm > 0 ? netProfit / totalKm : 0,
      fatPorKm: totalKm > 0 ? totalAmount / totalKm : 0
    }
  };
};
