
import React from 'react';

export const LoadingSpinner: React.FC = () => (
  <div className="flex flex-col items-center justify-center py-12 animate-in fade-in duration-500">
    <div className="w-12 h-12 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin mb-4 shadow-[0_0_15px_rgba(16,185,129,0.2)]"></div>
    <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">Carregando Inteligência...</span>
  </div>
);
