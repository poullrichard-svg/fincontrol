
import React from 'react';
import { formatCurrency } from '../utils/format';

interface ChartProps {
  data: Array<{ name: string; value: number }>;
  colors: string[];
}

// 1. Gráfico de Rosca (Donut) Aprimorado e Bem Alocado
export const DonutChart: React.FC<ChartProps> = ({ data = [], colors = [] }) => {
  const safeData = Array.isArray(data) ? data : [];
  const total = safeData.reduce((acc, item) => acc + (item.value || 0), 0);

  if (total === 0 || safeData.length === 0) return (
    <div className="flex flex-col items-center justify-center h-64 text-slate-700">
      <div className="w-32 h-32 rounded-full border-2 border-dashed border-slate-800 flex items-center justify-center mb-4">
        <span className="text-[10px] font-black uppercase text-center px-4">Sem Dados</span>
      </div>
    </div>
  );

  let accumulatedAngle = 0;

  return (
    <div className="flex flex-col items-center justify-between gap-8 w-full animate-in fade-in duration-700 h-full">
      <div className="relative w-48 h-48 flex-shrink-0">
        <svg viewBox="0 0 100 100" className="transform -rotate-90 w-full h-full drop-shadow-[0_10px_20px_rgba(0,0,0,0.4)]">
          {safeData.map((item, index) => {
            const percentage = item.value / total;
            const angle = percentage * 360;
            const largeArcFlag = percentage > 0.5 ? 1 : 0;
            const r = 42; 
            const cx = 50; const cy = 50;
            const x1 = cx + r * Math.cos((Math.PI * accumulatedAngle) / 180);
            const y1 = cy + r * Math.sin((Math.PI * accumulatedAngle) / 180);
            accumulatedAngle += angle;
            const x2 = cx + r * Math.cos((Math.PI * accumulatedAngle) / 180);
            const y2 = cy + r * Math.sin((Math.PI * accumulatedAngle) / 180);
            
            return (
              <path 
                key={index} 
                d={`M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${largeArcFlag} 1 ${x2} ${y2} Z`} 
                fill={colors[index % colors.length]} 
                stroke="#020617" 
                strokeWidth="2.5"
                className="transition-all duration-500 hover:scale-[1.05] cursor-pointer"
              />
            );
          })}
          <circle cx="50" cy="50" r="32" fill="#020617" />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="text-center">
              <span className="block text-[7px] font-black text-slate-500 uppercase tracking-widest mb-0.5">TOTAL</span>
              <span className="block text-sm font-black text-white leading-none">{formatCurrency(total)}</span>
          </div>
        </div>
      </div>

      <div className="w-full space-y-2 max-h-[140px] overflow-y-auto no-scrollbar pr-2">
        {safeData.map((item, index) => (
          <div key={index} className="flex items-center justify-between group py-1 border-b border-white/5 last:border-0">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full shadow-lg" style={{ backgroundColor: colors[index % colors.length], boxShadow: `0 0 6px ${colors[index % colors.length]}66` }} />
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tight group-hover:text-white transition-colors truncate max-w-[100px]">{item.name}</span>
            </div>
            <div className="text-right">
              <span className="block text-[10px] font-black text-white">{formatCurrency(item.value)}</span>
              <span className="block text-[7px] font-black text-slate-600">{( (item.value / total) * 100).toFixed(1)}%</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// 2. Gráfico de Barras Mensais - Refinado
export const MonthlyBarChart: React.FC<{
  data: Array<{ month: string, income: number, expense: number }>
}> = ({ data }) => {
  const maxVal = Math.max(...data.flatMap(d => [d.income, d.expense]), 1);

  return (
    <div className="w-full space-y-6">
      <div className="flex items-end justify-between gap-1 md:gap-3 h-48 md:h-64 px-1">
        {data.map((d, i) => (
          <div key={i} className="flex-1 flex flex-col items-center group gap-2 h-full justify-end">
            <div className="flex gap-1 items-end w-full h-full justify-center">
              {/* Barra de Receita */}
              <div 
                className="w-1.5 md:w-3 bg-gradient-to-t from-emerald-600 to-emerald-400 rounded-t-full transition-all duration-700 shadow-[0_-4px_10px_rgba(16,185,129,0.3)] hover:brightness-125"
                style={{ height: `${(d.income / maxVal) * 100}%` }}
              >
                <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[8px] p-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-all pointer-events-none whitespace-nowrap z-50 border border-white/10 shadow-xl">
                  {formatCurrency(d.income)}
                </div>
              </div>
              {/* Barra de Despesa */}
              <div 
                className="w-1.5 md:w-3 bg-gradient-to-t from-rose-600 to-rose-400 rounded-t-full transition-all duration-700 shadow-[0_-4px_10px_rgba(244,63,94,0.3)] hover:brightness-125"
                style={{ height: `${(d.expense / maxVal) * 100}%` }}
              >
                <div className="absolute -top-14 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[8px] p-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-all pointer-events-none whitespace-nowrap z-50 border border-white/10 shadow-xl">
                  {formatCurrency(d.expense)}
                </div>
              </div>
            </div>
            <span className="text-[8px] md:text-[9px] font-black text-slate-600 uppercase group-hover:text-slate-300 transition-colors">{d.month}</span>
          </div>
        ))}
      </div>
      <div className="flex justify-center gap-6 pt-4 border-t border-white/5">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
          <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Receitas</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-1.5 rounded-full bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.5)]" />
          <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Despesas</span>
        </div>
      </div>
    </div>
  );
};

// 3. Detalhamento de Despesas (Barras Horizontais)
export const CategoryBarChart: React.FC<ChartProps> = ({ data, colors }) => {
  const total = data.reduce((acc, i) => acc + i.value, 0);
  const sorted = [...data].sort((a, b) => b.value - a.value).slice(0, 5);

  return (
    <div className="space-y-5 w-full animate-in slide-in-from-right duration-700">
      {sorted.map((item, index) => {
        const percentage = (item.value / total) * 100;
        return (
          <div key={index} className="space-y-1.5 group">
            <div className="flex justify-between items-end">
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest group-hover:text-white transition-colors">{item.name}</span>
              <span className="text-[10px] font-black text-white">{formatCurrency(item.value)}</span>
            </div>
            <div className="h-2 w-full bg-slate-800/50 rounded-full overflow-hidden border border-white/5 p-0.5">
              <div 
                className="h-full rounded-full transition-all duration-1000 ease-out shadow-lg"
                style={{ 
                  width: `${percentage}%`, 
                  backgroundColor: colors[index % colors.length],
                  boxShadow: `0 0 10px ${colors[index % colors.length]}44`
                }} 
              />
            </div>
          </div>
        );
      })}
    </div>
  );
};
