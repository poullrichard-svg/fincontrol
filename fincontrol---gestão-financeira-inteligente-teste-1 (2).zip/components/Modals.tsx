
import React, { useState, useRef, useEffect } from 'react';
import { X, Upload, Check, BrainCircuit, FileText, Table, AlertCircle } from 'lucide-react';
import { formatDisplayAmount, formatCurrency, parseBRDateToISO, parseMoneyBR, normalizeHeader, detectDelimiter } from '../utils/format';
import { TRANSACTION_CATEGORIES, Goal, Transaction, DriverSession } from '../types';
import { TransactionSchema, DriverSessionSchema, GoalSchema, ShoppingItemSchema, TransactionInput, DriverSessionInput, GoalInput, ShoppingInput } from '../utils/schemas';
import { useAuth } from '../contexts/AuthContext';
import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { supabase, api } from '../services/supabase';

const inferCategory = (desc: string): string => {
  const d = (desc || "").toUpperCase();
  if (d.includes('POSTO') || d.includes('GASOL') || d.includes('COMBUST')) return 'Combustível';
  if (d.includes('MERCADO') || d.includes('IFOOD') || d.includes('SUPERMERC') || d.includes('SACOLAO')) return 'Alimentação';
  if (d.includes('UBER') || d.includes('99APP') || d.includes('CORRIDA')) return 'Transporte';
  if (d.includes('NETFLIX') || d.includes('SPOTIFY') || d.includes('STREAM') || d.includes('ASSINAT')) return 'Assinaturas';
  if (d.includes('UNIMED') || d.includes('FARMAC') || d.includes('DROG')) return 'Saúde';
  return 'Outros';
};

interface BaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}

const BaseModal: React.FC<BaseModalProps> = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-2xl animate-in fade-in duration-300">
      <div className="bg-[#0f172a] border border-white/5 w-full max-w-2xl rounded-[2.5rem] overflow-hidden shadow-2xl">
        <div className="p-6 md:p-8 border-b border-white/5 flex justify-between items-center bg-slate-900/40">
          <h3 className="text-xl font-black uppercase tracking-tight text-white">{title}</h3>
          <button onClick={onClose} className="text-slate-500 hover:text-white transition-colors p-2.5 rounded-xl bg-white/5">
            <X size={20} />
          </button>
        </div>
        <div className="p-6 md:p-8 max-h-[80vh] overflow-y-auto no-scrollbar">
          {children}
        </div>
      </div>
    </div>
  );
};

export const DataCenterModal: React.FC<{ 
  isOpen: boolean; 
  onClose: () => void; 
  transactions: Transaction[]; 
  selectedMonth: string; 
  onImport: (data: any[]) => Promise<void>; 
}> = ({ isOpen, onClose, transactions, selectedMonth, onImport }) => {
  const { notify } = useAuth();
  const [loading, setLoading] = useState(false);
  const [previewData, setPreviewData] = useState<any[]>([]);
  const [importStats, setImportStats] = useState<{total: number, inserted: number, rejected: number, errors: string[]} | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleExportExcel = () => {
    const filtered = transactions.filter(t => String(t.date || "").includes(selectedMonth));
    if (filtered.length === 0) { notify("Sem dados para exportar", "error"); return; }
    const data = filtered.map(t => ({ Data: t.date, Descrição: t.description, Categoria: t.category, Tipo: t.type === 'income' ? 'Entrada' : 'Saída', Valor: t.amount }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Transações");
    XLSX.writeFile(wb, `Extrato_${selectedMonth}.xlsx`);
    notify("Excel gerado!");
  };

  const handleExportPDF = () => {
    const filtered = transactions.filter(t => String(t.date || "").includes(selectedMonth));
    if (filtered.length === 0) { notify("Sem dados", "error"); return; }
    const doc = new jsPDF() as any;
    doc.autoTable({
      head: [['Data', 'Descrição', 'Categoria', 'Valor']],
      body: filtered.map(t => [t.date, t.description, t.category, formatCurrency(t.amount)]),
    });
    doc.save(`Relatorio_${selectedMonth}.pdf`);
  };

  const processFile = async (file: File) => {
    setLoading(true);
    setPreviewData([]);
    setImportStats(null);
    
    try {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = new TextDecoder().decode(e.target?.result as ArrayBuffer);
        const delimiter = detectDelimiter(text);
        
        let jsonData: any[] = [];
        try {
          const workbook = XLSX.read(e.target?.result, { type: 'array', codepage: 65001 });
          jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]], { raw: false });
        } catch (err) {
          notify("Falha ao ler o formato do arquivo", "error");
          setLoading(false);
          return;
        }

        let rejectedCount = 0;
        const errors: string[] = [];

        const mapped = jsonData.map((row: any, idx) => {
          const cleanRow: any = {};
          Object.keys(row).forEach(key => {
            cleanRow[normalizeHeader(key)] = row[key];
          });

          const rawDate = cleanRow.data || cleanRow.date || cleanRow.dt || cleanRow.transacao || cleanRow.vencimento;
          const rawDesc = cleanRow.descricao || cleanRow.description || cleanRow.estabelecimento || cleanRow.identificador_detalhado;
          const rawValue = cleanRow.valor || cleanRow.amount || cleanRow.value || cleanRow.r$ || cleanRow.saldo;
          const externalId = cleanRow.identificador || cleanRow.id_transacao || cleanRow.transaction_id || cleanRow.id || cleanRow.uuid || cleanRow.external_id;

          const isoDate = parseBRDateToISO(String(rawDate || ""));
          const amountValue = parseMoneyBR(rawValue);

          if (!isoDate) {
            rejectedCount++;
            errors.push(`Linha ${idx + 2}: Data inválida (${rawDate})`);
            return null;
          }

          if (isNaN(amountValue) || amountValue === 0) {
            rejectedCount++;
            errors.push(`Linha ${idx + 2}: Valor inválido (${rawValue})`);
            return null;
          }

          return {
            external_id: externalId ? String(externalId) : `auto-${isoDate}-${amountValue}-${idx}`,
            date: isoDate,
            description: String(rawDesc || "IMPORTACAO").trim().toUpperCase(),
            amount: Math.abs(amountValue),
            type: amountValue < 0 ? 'expense' : 'income',
            category: inferCategory(String(rawDesc))
          };
        }).filter(item => item !== null);

        setImportStats({ total: jsonData.length, inserted: mapped.length, rejected: rejectedCount, errors });
        setPreviewData(mapped);
        setLoading(false);
        if (mapped.length === 0) notify("Nenhum dado válido encontrado.", "error");
      };
      reader.readAsArrayBuffer(file);
    } catch (err: any) {
      notify("Erro no arquivo: " + err.message, "error");
      setLoading(false);
    }
  };

  return (
    <BaseModal isOpen={isOpen} onClose={onClose} title="Gestão de Dados">
      <div className="space-y-8">
        <div className="grid grid-cols-2 gap-4">
          <button onClick={handleExportExcel} className="flex flex-col items-center gap-3 p-6 bg-slate-900/60 rounded-3xl border border-white/5 hover:border-emerald-500/30 transition-all group">
            <Table className="text-emerald-500 group-hover:scale-110" size={24} />
            <span className="text-[10px] font-black uppercase text-slate-400">Exportar Excel</span>
          </button>
          <button onClick={handleExportPDF} className="flex flex-col items-center gap-3 p-6 bg-slate-900/60 rounded-3xl border border-white/5 hover:border-rose-500/30 transition-all group">
            <FileText className="text-rose-500 group-hover:scale-110" size={24} />
            <span className="text-[10px] font-black uppercase text-slate-400">Exportar PDF</span>
          </button>
        </div>

        <div className="space-y-4">
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-white/5 bg-slate-900/20 rounded-[2rem] p-10 flex flex-col items-center gap-4 cursor-pointer hover:bg-slate-900/40 transition-all"
          >
            <Upload className="text-slate-500" size={32} />
            <div className="text-center">
              <p className="text-sm font-bold text-white">Importar Extrato CSV/XLSX</p>
              <p className="text-[10px] text-slate-500 uppercase font-black mt-1">UTF-8 / Delimitador Automático</p>
            </div>
            <input type="file" ref={fileInputRef} className="hidden" onChange={(e) => e.target.files?.[0] && processFile(e.target.files[0])} accept=".csv,.xlsx,.xls" />
          </div>
        </div>

        {loading && (
          <div className="py-10 text-center animate-pulse">
            <BrainCircuit className="mx-auto text-emerald-500 mb-4" size={40} />
            <p className="text-[10px] font-black uppercase text-emerald-500 tracking-widest">Processando Inteligência de Dados...</p>
          </div>
        )}

        {importStats && (
          <div className="space-y-4">
             <div className="p-4 bg-slate-900/50 border border-white/5 rounded-2xl">
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Relatório de Importação</p>
                <div className="grid grid-cols-3 gap-2 text-center">
                   <div className="bg-white/5 p-2 rounded-xl"><p className="text-lg font-black">{importStats.total}</p><p className="text-[7px] font-black text-slate-500 uppercase">Total</p></div>
                   <div className="bg-emerald-500/10 p-2 rounded-xl border border-emerald-500/20"><p className="text-lg font-black text-emerald-400">{importStats.inserted}</p><p className="text-[7px] font-black text-emerald-500 uppercase">Válidos</p></div>
                   <div className="bg-rose-500/10 p-2 rounded-xl border border-rose-500/20"><p className="text-lg font-black text-rose-400">{importStats.rejected}</p><p className="text-[7px] font-black text-rose-500 uppercase">Rejeitados</p></div>
                </div>
             </div>
          </div>
        )}

        {previewData.length > 0 && !loading && (
          <div className="space-y-6">
            <div className="bg-slate-950 rounded-[1.5rem] border border-white/5 overflow-hidden">
               <div className="p-4 bg-slate-900/50 border-b border-white/5 flex justify-between items-center">
                  <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Prévia ({previewData.length})</p>
               </div>
               <div className="max-h-60 overflow-y-auto no-scrollbar">
                  <table className="w-full text-left border-collapse">
                    <tbody className="divide-y divide-white/5">
                      {previewData.map((item, idx) => (
                        <tr key={idx} className="hover:bg-white/5 transition-colors">
                          <td className="p-3 text-[10px] font-mono text-slate-400">{item.date}</td>
                          <td className="p-3 text-[10px] font-bold text-white uppercase truncate max-w-[180px]">{item.description}</td>
                          <td className={`p-3 text-[10px] font-black text-right ${item.type === 'income' ? 'text-emerald-400' : 'text-rose-400'}`}>{formatCurrency(item.amount)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
               </div>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setPreviewData([])} className="flex-1 bg-slate-800 text-white font-black py-4 rounded-xl uppercase text-[10px] active:scale-95 transition-all">Limpar</button>
              <button 
                onClick={async () => {
                  setLoading(true);
                  await onImport(previewData);
                  setPreviewData([]);
                  setLoading(false);
                  onClose();
                }} 
                className="flex-[2] bg-emerald-500 text-slate-950 font-black py-4 rounded-xl uppercase text-[10px] shadow-xl active:scale-95 transition-all"
              >
                Upsert {previewData.length} Registros
              </button>
            </div>
          </div>
        )}
      </div>
    </BaseModal>
  );
};

export const TransactionModal: React.FC<{ 
  isOpen: boolean; 
  onClose: () => void; 
  onSubmit: (data: TransactionInput) => Promise<boolean>;
}> = ({ isOpen, onClose, onSubmit }) => {
  const { notify } = useAuth();
  const [isFixed, setIsFixed] = useState(false);
  const [type, setType] = useState<'income' | 'expense'>('expense');
  const [amountRaw, setAmountRaw] = useState('');
  
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const amt = (parseInt(amountRaw) || 0) / 100;
    const rawData = {
      description: String(f.get('description') || ""),
      amount: amt,
      type,
      category: String(f.get('category') || ""),
      payment_method: String(f.get('payment_method') || "Pix"),
      date: isFixed ? null : String(f.get('date') || new Date().toISOString().split('T')[0]),
      is_fixed: isFixed,
      external_id: null
    };
    const validation = TransactionSchema.safeParse(rawData);
    if (!validation.success) { notify(validation.error.issues[0].message, 'error'); return; }
    const success = await onSubmit(validation.data);
    if (success) { setAmountRaw(''); onClose(); }
  };

  return (
    <BaseModal isOpen={isOpen} onClose={onClose} title="Novo Lançamento">
      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="grid grid-cols-2 gap-3">
          <button type="button" onClick={() => setIsFixed(false)} className={`py-3.5 rounded-xl font-black uppercase text-[9px] border-2 transition-all ${!isFixed ? 'border-emerald-500 text-emerald-400 bg-emerald-500/5' : 'border-slate-800 text-slate-500'}`}>Variável</button>
          <button type="button" onClick={() => setIsFixed(true)} className={`py-3.5 rounded-xl font-black uppercase text-[9px] border-2 transition-all ${isFixed ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5' : 'border-slate-800 text-slate-500'}`}>Fixo</button>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <button type="button" onClick={() => setType('expense')} className={`py-3.5 rounded-xl font-black uppercase text-[9px] border-2 transition-all ${type === 'expense' ? 'border-rose-500 text-rose-400 bg-rose-500/5' : 'border-slate-800 text-slate-500'}`}>Saída</button>
          <button type="button" onClick={() => setType('income')} className={`py-3.5 rounded-xl font-black uppercase text-[9px] border-2 transition-all ${type === 'income' ? 'border-emerald-500 text-emerald-400 bg-emerald-500/5' : 'border-slate-800 text-slate-500'}`}>Entrada</button>
        </div>
        <div className="space-y-1">
          <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Descrição</label>
          <input name="description" required placeholder="Ex: Mercado" className="w-full bg-slate-900 border border-white/5 p-4 rounded-xl text-white outline-none font-bold" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Valor</label>
            <input type="text" inputMode="decimal" value={formatDisplayAmount(amountRaw)} onChange={e => setAmountRaw(e.target.value.replace(/\D/g, ""))} required className="w-full bg-slate-900 border border-white/5 p-4 rounded-xl text-white outline-none font-mono" />
          </div>
          <div className="space-y-1">
            <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Categoria</label>
            <select name="category" required className="w-full bg-slate-900 border border-white/5 p-4 rounded-xl text-white outline-none text-[10px] uppercase font-black">
              {TRANSACTION_CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
            </select>
          </div>
        </div>
        {!isFixed && (
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Data</label>
              <input name="date" type="date" required defaultValue={new Date().toISOString().split('T')[0]} className="w-full bg-slate-900 border border-white/5 p-4 rounded-xl text-white outline-none [color-scheme:dark]" />
            </div>
            <div className="space-y-1">
              <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Pagamento</label>
              <select name="payment_method" className="w-full bg-slate-900 border border-white/5 p-4 rounded-xl text-white outline-none text-[10px] font-black uppercase">
                <option value="Pix">Pix</option>
                <option value="Débito">Débito</option>
                <option value="Crédito">Crédito</option>
                <option value="Dinheiro">Dinheiro</option>
              </select>
            </div>
          </div>
        )}
        <button type="submit" className="w-full bg-emerald-500 text-slate-950 font-black py-4 rounded-xl uppercase tracking-widest active:scale-95 transition-all mt-2">Salvar</button>
      </form>
    </BaseModal>
  );
};

export const GoalModal: React.FC<{ 
  isOpen: boolean; 
  onClose: () => void; 
  onSubmit: (data: any) => Promise<boolean>;
}> = ({ isOpen, onClose, onSubmit }) => {
  const { notify } = useAuth();
  const [type, setType] = useState<'financial' | 'activity'>('financial');
  const [targetRaw, setTargetRaw] = useState('');

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const dbPayload = {
      description: String(f.get('description') || ""),
      target_amount: type === 'financial' ? (parseInt(targetRaw) || 0) / 100 : parseFloat(f.get('target_amount') as string),
      current_amount: 0,
      type: type
    };
    if (isNaN(dbPayload.target_amount) || dbPayload.target_amount <= 0) { notify("Defina um alvo válido", "error"); return; }
    const success = await onSubmit(dbPayload);
    if (success) { setTargetRaw(''); onClose(); }
  };

  return (
    <BaseModal isOpen={isOpen} onClose={onClose} title="Nova Meta">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-2 gap-3">
          <button type="button" onClick={() => setType('financial')} className={`py-4 rounded-xl font-black uppercase text-[10px] border-2 transition-all ${type === 'financial' ? 'border-emerald-500 text-emerald-400 bg-emerald-500/5' : 'border-slate-800 text-slate-500'}`}>Financeira</button>
          <button type="button" onClick={() => setType('activity')} className={`py-4 rounded-xl font-black uppercase text-[10px] border-2 transition-all ${type === 'activity' ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5' : 'border-slate-800 text-slate-500'}`}>Atividade</button>
        </div>
        <div className="space-y-1">
          <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">O que você quer conquistar?</label>
          <input name="description" required placeholder="Ex: Viagem ou Ler 10 Livros" className="w-full bg-slate-900 border border-white/5 p-4 rounded-xl text-white outline-none font-bold" />
        </div>
        <div className="space-y-1">
          <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Alvo Final {type === 'financial' ? '(R$)' : '(Quantidade)'}</label>
          {type === 'financial' ? (
            <input type="text" value={formatDisplayAmount(targetRaw)} onChange={e => setTargetRaw(e.target.value.replace(/\D/g, ""))} required className="w-full bg-slate-900 border border-white/5 p-4 rounded-xl text-white outline-none font-mono" />
          ) : (
            <input name="target_amount" type="number" step="0.1" required className="w-full bg-slate-900 border border-white/5 p-4 rounded-xl text-white outline-none font-mono" />
          )}
        </div>
        <button type="submit" className="w-full bg-emerald-500 text-slate-950 font-black py-4 rounded-xl uppercase tracking-widest active:scale-95 transition-all">Criar Meta</button>
      </form>
    </BaseModal>
  );
};

export const DriverModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: DriverSessionInput) => Promise<boolean>;
  initialData?: DriverSession | null;
}> = ({ isOpen, onClose, onSubmit, initialData }) => {
  const { notify } = useAuth();
  const [amountRaw, setAmountRaw] = useState('');
  const [fuelRaw, setFuelRaw] = useState('');
  const [foodRaw, setFoodRaw] = useState('');
  const [otherRaw, setOtherRaw] = useState('');

  useEffect(() => { 
    if (initialData) {
      setAmountRaw((initialData.amount * 100).toFixed(0));
      setFuelRaw(((initialData.fuel_spent || 0) * 100).toFixed(0));
      setFoodRaw(((initialData.food_spent || 0) * 100).toFixed(0));
      setOtherRaw(((initialData.other_spent || 0) * 100).toFixed(0));
    } else {
      setAmountRaw('');
      setFuelRaw('');
      setFoodRaw('');
      setOtherRaw('');
    }
  }, [initialData, isOpen]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    
    const rawData = {
      date: String(f.get('date') || new Date().toISOString().split('T')[0]),
      app: (f.get('app') || 'Uber') as any,
      amount: (parseInt(amountRaw) || 0) / 100,
      trips: parseInt(f.get('trips') as string) || 0,
      km_driven: parseFloat(f.get('km_driven') as string) || 0,
      hours_worked: String(f.get('hours_worked') || '08:00'),
      fuel_spent: (parseInt(fuelRaw) || 0) / 100,
      food_spent: (parseInt(foodRaw) || 0) / 100,
      other_spent: (parseInt(otherRaw) || 0) / 100,
      observation: String(f.get('observation') || "")
    };
    
    const validation = DriverSessionSchema.safeParse(rawData);
    if (!validation.success) { 
      notify(validation.error.issues[0].message, 'error'); 
      return; 
    }
    const success = await onSubmit(validation.data);
    if (success) onClose();
  };

  return (
    <BaseModal isOpen={isOpen} onClose={onClose} title="Sessão Motorista">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
             <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Data</label>
             <input name="date" type="date" required defaultValue={initialData?.date || new Date().toISOString().split('T')[0]} className="w-full bg-slate-900 border border-white/5 p-4 rounded-xl text-white outline-none [color-scheme:dark]" />
          </div>
          <div className="space-y-1">
             <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Plataforma</label>
             <select name="app" defaultValue={initialData?.app || "Uber"} className="w-full bg-slate-900 border border-white/5 p-4 rounded-xl text-white outline-none text-[10px] font-black uppercase">
                <option value="Uber">Uber</option>
                <option value="99">99</option>
                <option value="InDrive">InDrive</option>
                <option value="Particular">Particular</option>
             </select>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Ganhos Brutos</label>
            <input type="text" value={formatDisplayAmount(amountRaw)} onChange={e => setAmountRaw(e.target.value.replace(/\D/g, ""))} required className="w-full bg-slate-900 border border-white/5 p-4 rounded-xl text-white outline-none font-mono" placeholder="R$ 0,00" />
          </div>
          <div className="space-y-1">
            <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Horas Trabalhadas</label>
            <input name="hours_worked" type="time" required defaultValue={initialData?.hours_worked || "08:00"} className="w-full bg-slate-900 border border-white/5 p-4 rounded-xl text-white outline-none" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
             <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest">KM Rodados</label>
             <input name="km_driven" type="number" step="0.1" required defaultValue={initialData?.km_driven} placeholder="KM" className="w-full bg-slate-900 border border-white/5 p-4 rounded-xl text-white outline-none" />
          </div>
          <div className="space-y-1">
             <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Viagens</label>
             <input name="trips" type="number" required defaultValue={initialData?.trips} placeholder="Viagens" className="w-full bg-slate-900 border border-white/5 p-4 rounded-xl text-white outline-none" />
          </div>
        </div>

        <div className="pt-4 border-t border-white/5">
          <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-4 text-center">Despesas da Sessão</p>
          <div className="grid grid-cols-3 gap-3">
             <div className="space-y-1">
                <label className="text-[8px] font-black text-slate-500 uppercase">Combustível</label>
                <input type="text" value={formatDisplayAmount(fuelRaw)} onChange={e => setFuelRaw(e.target.value.replace(/\D/g, ""))} className="w-full bg-slate-950 border border-white/5 p-3 rounded-xl text-white outline-none font-mono text-xs" placeholder="R$ 0,00" />
             </div>
             <div className="space-y-1">
                <label className="text-[8px] font-black text-slate-500 uppercase">Alimentação</label>
                <input type="text" value={formatDisplayAmount(foodRaw)} onChange={e => setFoodRaw(e.target.value.replace(/\D/g, ""))} className="w-full bg-slate-950 border border-white/5 p-3 rounded-xl text-white outline-none font-mono text-xs" placeholder="R$ 0,00" />
             </div>
             <div className="space-y-1">
                <label className="text-[8px] font-black text-slate-500 uppercase">Outros</label>
                <input type="text" value={formatDisplayAmount(otherRaw)} onChange={e => setOtherRaw(e.target.value.replace(/\D/g, ""))} className="w-full bg-slate-950 border border-white/5 p-3 rounded-xl text-white outline-none font-mono text-xs" placeholder="R$ 0,00" />
             </div>
          </div>
        </div>

        <button type="submit" className="w-full bg-amber-500 text-slate-950 font-black py-4 rounded-xl uppercase tracking-widest shadow-lg mt-4 active:scale-95 transition-all">
          {initialData ? 'Atualizar Sessão' : 'Salvar Corrida'}
        </button>
      </form>
    </BaseModal>
  );
};

export const AporteModal: React.FC<{ isOpen: boolean; onClose: () => void; goal: Goal | null; onSubmit: (amount: number) => Promise<boolean>; }> = ({ isOpen, onClose, goal, onSubmit }) => {
  const [valRaw, setValRaw] = useState('');
  if (!goal) return null;
  const isFin = goal.type === 'financial';
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const val = isFin ? (parseInt(valRaw) || 0) / 100 : parseFloat(valRaw);
    if (await onSubmit(val)) { setValRaw(''); onClose(); }
  };
  return (
    <BaseModal isOpen={isOpen} onClose={onClose} title={`Aportar: ${goal.description}`}>
      <form onSubmit={handleSubmit} className="space-y-6 text-center">
        {isFin ? <input type="text" autoFocus value={formatDisplayAmount(valRaw)} onChange={e => setValRaw(e.target.value.replace(/\D/g, ""))} className="w-full bg-transparent text-center text-4xl font-black text-emerald-400 outline-none" />
               : <input type="number" autoFocus step="0.1" value={valRaw} onChange={e => setValRaw(e.target.value)} className="w-full bg-transparent text-center text-4xl font-black text-indigo-400 outline-none" />}
        <button type="submit" className="w-full bg-emerald-500 text-slate-950 font-black py-4 rounded-xl uppercase shadow-lg">Confirmar</button>
      </form>
    </BaseModal>
  );
};

export const UpdatePriceModal: React.FC<{ isOpen: boolean; onClose: () => void; itemName: string; onSubmit: (price: number) => Promise<boolean>; }> = ({ isOpen, onClose, itemName, onSubmit }) => {
  const [priceRaw, setPriceRaw] = useState('');
  const handleSubmit = async (e: React.FormEvent) => { e.preventDefault(); const p = (parseInt(priceRaw) || 0) / 100; if (await onSubmit(p)) { setPriceRaw(''); onClose(); } };
  return (
    <BaseModal isOpen={isOpen} onClose={onClose} title={`Preço: ${itemName}`}>
      <form onSubmit={handleSubmit} className="space-y-6">
        <input type="text" autoFocus value={formatDisplayAmount(priceRaw)} onChange={e => setPriceRaw(e.target.value.replace(/\D/g, ""))} className="w-full bg-slate-900 border border-white/5 p-6 rounded-2xl text-center text-3xl font-black text-white outline-none" />
        <button type="submit" className="w-full bg-emerald-500 text-slate-950 font-black py-4 rounded-xl shadow-lg">Salvar Preço</button>
      </form>
    </BaseModal>
  );
};

export const ShoppingModal: React.FC<{ isOpen: boolean; onClose: () => void; onSubmit: (data: ShoppingInput) => Promise<boolean>; }> = ({ isOpen, onClose, onSubmit }) => {
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const success = await onSubmit({ name: String(f.get('name') || ""), quantity: parseFloat(f.get('quantity') as string) || 1, unit: String(f.get('unit') || 'un'), estimated_price: 0, completed: false });
    if (success) onClose();
  };
  return (
    <BaseModal isOpen={isOpen} onClose={onClose} title="Novo Item de Compra">
      <form onSubmit={handleSubmit} className="space-y-6">
        <input name="name" required placeholder="O que você precisa?" className="w-full bg-slate-900 border border-white/5 p-4 rounded-xl text-white outline-none font-bold" />
        <div className="grid grid-cols-2 gap-4">
          <input name="quantity" type="number" defaultValue="1" className="w-full bg-slate-900 border border-white/5 p-4 rounded-xl text-white outline-none font-black" />
          <select name="unit" className="w-full bg-slate-900 border border-white/5 p-4 rounded-xl text-white outline-none text-[10px] font-black uppercase">
            <option value="un">Unidade</option><option value="kg">Quilo (KG)</option><option value="pacote">Pacote</option><option value="litro">Litro (L)</option>
          </select>
        </div>
        <button type="submit" className="w-full bg-emerald-500 text-slate-950 font-black py-4 rounded-xl uppercase tracking-widest shadow-lg">Adicionar à Lista</button>
      </form>
    </BaseModal>
  );
};
