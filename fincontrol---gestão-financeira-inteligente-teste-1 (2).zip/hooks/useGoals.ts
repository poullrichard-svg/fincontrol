
import { useState, useCallback } from 'react';
import { api } from '../services/supabase';
import { Goal } from '../types';
import { useAuth } from '../contexts/AuthContext';

export const useGoals = () => {
  const { user, notify } = useAuth();
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchGoals = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const { data, error } = await api.goals.getAll(user.id);
      if (error) notify(error.message, 'error');
      else setGoals(data || []);
    } finally {
      setLoading(false);
    }
  }, [user, notify]);

  const addGoal = async (data: any) => {
    try {
      const { error } = await api.goals.insert({ ...data, user_id: user?.id });
      if (error) {
        notify(error.message, 'error');
        return false;
      }
      notify('Meta criada com sucesso');
      await fetchGoals();
      return true;
    } catch (e: any) {
      notify(e.message, 'error');
      return false;
    }
  };

  const deleteGoal = async (id: string) => {
    try {
      // Atualização otimista
      setGoals(prev => prev.filter(goal => goal.id !== id));

      const { error } = await api.goals.delete(id);
      if (error) {
        notify(error.message, 'error');
        await fetchGoals();
        return false;
      }
      notify('Meta excluída');
      return true;
    } catch (e: any) {
      notify(e.message, 'error');
      await fetchGoals();
      return false;
    }
  };

  return { goals, loading, fetchGoals, addGoal, deleteGoal };
};
