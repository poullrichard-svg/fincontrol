import { useState, useCallback } from 'react';
import { api } from '../services/supabase';
import { Transaction } from '../types';
import { useAuth } from '../contexts/AuthContext';

export const useFinances = () => {
  const { user, notify } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [fixedTransactions, setFixedTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchTransactions = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await api.transactions.getAll(user.id);
    if (error) notify(error.message, 'error');
    else setTransactions(data || []);
    setLoading(false);
  }, [user, notify]);

  const fetchFixed = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await api.transactions.getFixed(user.id);
    if (error) notify(error.message, 'error');
    else setFixedTransactions(data || []);
    setLoading(false);
  }, [user, notify]);

  const deleteTransaction = async (id: string, isFixed: boolean) => {
    const { error } = await api.transactions.delete(id, isFixed);
    if (error) notify(error.message, 'error');
    else {
      notify('Lançamento excluído com sucesso');
      isFixed ? fetchFixed() : fetchTransactions();
    }
  };

  return { 
    transactions, 
    fixedTransactions, 
    loading, 
    fetchTransactions, 
    fetchFixed, 
    deleteTransaction 
  };
};