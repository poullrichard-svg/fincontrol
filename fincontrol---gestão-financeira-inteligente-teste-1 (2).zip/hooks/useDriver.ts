import { useState, useCallback } from 'react';
import { api } from '../services/supabase';
import { DriverSession } from '../types';
import { useAuth } from '../contexts/AuthContext';

export const useDriver = () => {
  const { user, notify } = useAuth();
  const [sessions, setSessions] = useState<DriverSession[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchSessions = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await api.driver.getAll(user.id);
    if (error) notify(error.message, 'error');
    else setSessions(data || []);
    setLoading(false);
  }, [user, notify]);

  const addSession = async (data: any) => {
    const { error } = await api.driver.insert({ ...data, user_id: user?.id });
    if (error) {
      notify(error.message, 'error');
      return false;
    }
    notify('Sessão registrada com sucesso');
    fetchSessions();
    return true;
  };

  const deleteSession = async (id: string) => {
    const { error } = await api.driver.delete(id);
    if (error) notify(error.message, 'error');
    else {
      notify('Sessão excluída');
      fetchSessions();
    }
  };

  return { sessions, loading, fetchSessions, addSession, deleteSession };
};