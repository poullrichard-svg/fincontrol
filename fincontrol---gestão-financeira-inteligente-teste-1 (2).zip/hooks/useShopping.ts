
import { useState, useCallback } from 'react';
import { api } from '../services/supabase';
import { ShoppingItem } from '../types';
import { useAuth } from '../contexts/AuthContext';

export const useShopping = () => {
  const { user, notify } = useAuth();
  const [items, setItems] = useState<ShoppingItem[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchItems = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const { data, error } = await api.shopping.getAll(user.id);
      if (error) notify(error.message, 'error');
      else setItems(data || []);
    } finally {
      setLoading(false);
    }
  }, [user, notify]);

  const toggleComplete = async (item: ShoppingItem) => {
    try {
      const { error } = await api.shopping.upsert({ ...item, completed: !item.completed });
      if (error) notify(error.message, 'error');
      else await fetchItems();
    } catch (e: any) {
      notify(e.message, 'error');
    }
  };

  const addItem = async (data: any) => {
    try {
      const { error } = await api.shopping.upsert({ ...data, user_id: user?.id });
      if (error) {
        notify(error.message, 'error');
        return false;
      }
      await fetchItems();
      return true;
    } catch (e: any) {
      notify(e.message, 'error');
      return false;
    }
  };

  const deleteItem = async (id: string) => {
    try {
      // Atualização otimista: remove do estado antes mesmo do banco responder
      setItems(prev => prev.filter(item => item.id !== id));
      
      const { error } = await api.shopping.delete(id);
      if (error) {
        notify(error.message, 'error');
        // Se der erro, reverte (opcional, aqui apenas avisamos e recarregamos)
        await fetchItems();
        return false;
      }
      notify('Item removido da lista');
      return true;
    } catch (e: any) {
      notify(e.message, 'error');
      await fetchItems();
      return false;
    }
  };

  return { items, loading, fetchItems, toggleComplete, addItem, deleteItem };
};
