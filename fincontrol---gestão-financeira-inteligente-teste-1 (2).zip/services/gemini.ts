
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const extractTransactionsFromDocument = async (base64Data: string, mimeType: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [
      {
        parts: [
          {
            inlineData: {
              data: base64Data,
              mimeType: mimeType
            }
          },
          {
            text: `Aja como um robô contador de alta precisão especializado em processamento de extratos (OCR financeiro).
            Analise este documento (imagem ou PDF) e identifique TODOS os lançamentos financeiros.
            
            REGRAS DE EXTRAÇÃO:
            1. Capture apenas transações individuais. Ignore saldos (anterior, atual, bloqueado).
            2. Identifique claramente se é Entrada (Crédito/Recebido) ou Saída (Débito/Pago).
            3. Para a "description", use o nome do estabelecimento ou motivo (ex: "POSTO IPIRANGA", "TRANSF RECEBIDA JOAO").
            4. Converta todos os valores para números decimais positivos.
            5. Datas devem ser convertidas para o padrão ISO: YYYY-MM-DD.
            6. Classifique cada item em uma destas categorias: Moradia, Alimentação, Transporte, Lazer, Saúde, Educação, Combustível, Assinaturas, Outros.
            
            FORMATO DE RETORNO:
            Retorne APENAS um array JSON puro.
            Exemplo: [{"description": "EXEMPLO", "amount": 10.50, "type": "expense", "date": "2024-01-01", "category": "Outros"}]`
          }
        ]
      }
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            description: { type: Type.STRING },
            amount: { type: Type.NUMBER },
            type: { type: Type.STRING, enum: ["income", "expense"] },
            date: { type: Type.STRING },
            category: { type: Type.STRING }
          },
          required: ["description", "amount", "type", "date"]
        }
      }
    }
  });

  try {
    const text = response.text || "[]";
    return JSON.parse(text);
  } catch (e) {
    console.error("Falha ao processar resposta do Gemini:", e);
    return [];
  }
};
