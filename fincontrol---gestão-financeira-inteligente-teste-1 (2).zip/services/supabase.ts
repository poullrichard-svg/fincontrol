
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = (import.meta as any).env?.VITE_SUPABASE_URL || 'https://xfzovpgksotlyjqqhjtg.supabase.co';
const SUPABASE_ANON_KEY = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY || 'sb_publishable_2AEKLFtJ5XbzIRNamr90hg_Xokeu1KP';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

export const api = {
  transactions: {
    getAll: (userId: string) => supabase.from('transactions').select('*').eq('user_id', userId).order('date', { ascending: false }),
    getFixed: (userId: string) => supabase.from('fixed_transactions').select('*').eq('user_id', userId),
    delete: (id: string, isFixed: boolean) => supabase.from(isFixed ? 'fixed_transactions' : 'transactions').delete().eq('id', id),
    upsert: (table: 'transactions' | 'fixed_transactions', data: any) => {
      if (table === 'transactions') {
        // Usa external_id para evitar duplicidade na importação
        return supabase.from(table).upsert(data, { 
          onConflict: 'external_id',
          ignoreDuplicates: true 
        });
      }
      return supabase.from(table).upsert(data);
    }
  },
  driver: {
    getAll: (userId: string) => supabase.from('driver_sessions').select('*').eq('user_id', userId).order('date', { ascending: false }),
    insert: (data: any) => supabase.from('driver_sessions').insert(data),
    delete: (id: string) => supabase.from('driver_sessions').delete().eq('id', id)
  },
  goals: {
    getAll: (userId: string) => supabase.from('goals').select('*').eq('user_id', userId).order('created_at', { ascending: false }),
    insert: (data: any) => supabase.from('goals').insert(data),
    update: (id: string, data: any) => supabase.from('goals').update(data).eq('id', id),
    delete: (id: string) => supabase.from('goals').delete().eq('id', id)
  },
  shopping: {
    getAll: (userId: string) => supabase.from('shopping_items').select('*').eq('user_id', userId).order('created_at', { ascending: false }),
    upsert: (data: any) => supabase.from('shopping_items').upsert(data),
    delete: (id: string) => supabase.from('shopping_items').delete().eq('id', id)
  }
};
